/**
 * Modulo de respuestas del soporte
 * @author Desarrollador02 - Miguel Muslaco
 * @param   {object}   mongoose [Instancia]
 */
module.exports = function (mongoose) {

  var Schema = mongoose.Schema;

  // Objeto modelo de Mongoose
  var supportinfoSchema = new Schema({
    sticker: {
      type: mongoose.Schema.Types.ObjectId,
    },
    user: {
      type: mongoose.Schema.Types.ObjectId,
    },
    respuesta: {
      type: String,
    },
    fecha_registro: {
      type: Date,
      default: Date.now
    },
    attachments: {
      type: Array,
      default: []
    },
  });
  return mongoose.model('supportsDetail', supportinfoSchema);
};
