/**
 * Estructura de log para soportes
 * @author Naycoolgonzalez
 * @param   {object}  mongoose
 * @returns {object}
 */
module.exports = function (mongoose) {

  var Schema = mongoose.Schema;

  // Objeto modelo de Mongoose
  var log_supports = new Schema({
    ticket: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
    },
    action: {
      type: String
    },
    data: {
      type: String
    },
    by: {
      type: mongoose.Schema.Types.ObjectId,
    },
    viewed: {
      type: Array,
      default: []
    },
    date: {
      type: Date,
      default: Date.now
    }
  });

  return mongoose.model('log_supports', log_supports);
};
