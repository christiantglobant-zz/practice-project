/***************************************************
 * Users Schema
 * @package Shema
 * @author Naycool Gonzalez <naycoolgonzalez@gmail.com>
 * @description: Estructura de usuarios
 ****************************************************/

module.exports = function (mongoose) {

  var Schema = mongoose.Schema;

  // Objeto modelo de Mongoose
  var UserSchema = new Schema({
    user: {
      type: String,
      required: true,
      index: {
        unique: true
      }
    },
    image: {
      type: String,
      default: "undefined"
    },
    name: {
      type: String,
      required: true
    },
    lastname: {
      type: String
    },
    email: {
      type: String,
      required: true
    },
    tel: {
      type: String
    },
    password: {
      type: String,
      required: true,
    },
    lastlogin: {
      type: Date
    },
    lastUpdate: {
      type: Date
    },
    status: {
      type: Boolean
    },
    created_by: {
      type: String,
      required: true
    }
  });


  return mongoose.model('users', UserSchema);
};
