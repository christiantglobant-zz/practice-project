/***************************************************
 * Users
 * @package Angular
 * @author Miguel Muslaco <mjmuslaco@gmail.com>
 * @description: model de soportes
 ****************************************************/

var async = require('async');
var conect = require('../config/mongoose.js');
var Mycrypt = require('../config/crypto.js');
var Messages = require('../lib/Messages.js');
var Helpers = require('../helpers/helpers.js');
var Promise = require('promise');
var fs = require('fs');

var raiz = "app/uploads";
var folder = "clients";

/**
 * Listar todos los clientes
 * @author Desarrollador02 - Miguel Muslaco
 * @returns {object} [Listar todos los clienets]
 */
var allClients = function () {
  return new Promise(function (resolve, reject) {
    global.db.clientes.find({}, function (error, data) {
      if (error) {
        reject({
          event: false,
          data: error,
          msj: Messages.global.error.error
        });
      } else {
        resolve({
          event: data.length > 0,
          data: data,
          msj: data.length ? Messages.zonesafe.client.success.allClients : Messages.zonesafe.client.error.allClients
        });
      }
    }).sort({razon_social:1});
  });
};

/**
 * Nuevo cliente
 * @author Desarrollador02 - Miguel Muslaco
 * @param   {object}   client [[Description]]
 */
var newClient = function (client) {
  var path = raiz + "/" + folder;

  if (!fs.existsSync(raiz))
    fs.mkdirSync(raiz);
  if (!fs.existsSync(path))
    fs.mkdirSync(path);

  var insert = new global.db.clientes({
    identificacion: client.nit,
    digito_verif: client.cod,
    razon_social: client.business_name,
    nomb_comercial: client.tradename,
    email: client.mail,
    celular: client.phone,
    ultima_actualizacion: '',
  });
  return new Promise(function (resolve, reject) {
    insert.save(function (error, data) {
      if (error) {
        resolve({
          event: false,
          data: error,
          msj: error.message
        });
      } else {

        if (Helpers.emptyDatas([client.image, data._id])) {
          //data.image = data._id + '.jpg';
          client.image = client.image.replace("data:image/jpeg;base64,", "");
          fs.writeFile(path + "/" + data._id + ".jpg", client.image, {
            encoding: 'base64'
          }, function (err) {
            global.db.clientes.update({
              _id: data._id
            }, {
              image: data._id + '.jpg'
            }, function (error, update) {

            });
          });
        }

        resolve({
          event: data._id !== undefined,
          data: data,
          msj: data._id !== undefined ? Messages.zonesafe.client.success.new : Messages.zonesafe.client.error.new
        });
      }
    });
  });
};
/**
 * Listar la informacion del cliente
 * @author Desarrollador02 - Miguel Muslaco
 * @param   {object} clients [Datos del clientes]
 * @returns {object}
 */
var getInfoClient = function (clients) {
  return new Promise(function (resolve, reject) {
    global.db.clientes.findOne({
      _id: clients
    }, function (error, data) {
      if (error) {
        reject({
          event: false,
          data: error,
          msj: Messages.global.error.error
        });
      } else {
        resolve({
          event: data.length > 0,
          data: data,
          msj: data.length ? Messages.zonesafe.client.success.infoClient : Messages.zonesafe.client.error.infoClient
        });
      }
    });
  });
};

/**
 * Actualizo la informacion del cliente
 * @author Desarrollador02 - Miguel Muslaco
 * @param   {object}   client [Datos del cliente]
 * @returns {object}
 */
var update = function (client) {
  var path = raiz + "/" + folder;
  if (client.image.split('.').pop() !== "jpg") {
    var img = client.image.replace("data:image/jpeg;base64,", "");
    client.image = client._id + ".jpg";
    fs.writeFile(path + "/" + client._id + ".jpg", img, {
      encoding: 'base64'
    }, function (err) {
      console.log(err);
    });
  }

  return new Promise(function (resolve, reject) {
    global.db.clientes.update({
      _id: client._id
    }, {
      celular: client.celular,
      digito_verif: client.digito_verif,
      email: client.email,
      identificacion: client.identificacion,
      nomb_comercial: client.nomb_comercial,
      razon_social: client.razon_social,
      image: client.image,
      ultima_actualizacion: new Date(),
    }, function (error, data) {
      if (error) {
        reject({
          event: false,
          data: error,
          msj: error.message
        });
      } else {
        data.image = client.image;
        resolve({
          event: data.nModified === 1,
          data: data,
          msj: data.nModified === 1 ? Messages.zonesafe.client.success.update : Messages.zonesafe.client.error.update
        });
      }
    });
  });
};
/**
 * Desahabilitar clientes
 * @author Desarrollador02 - Miguel Muslaco
 * @param   {object}   client [Datos del cliente]
 * @returns {object}
 */
var disableClient = function (client) {
  return new Promise(function (resolve, reject) {
    global.db.clientes.update({
      _id: client._id
    }, {
      estado: client.estado,
    }, function (error, data) {
      if (error) {
        reject({
          event: false,
          data: error,
          msj: error.message
        });
      } else {
        resolve({
          event: data.nModified === 1,
          data: data,
          msj: data.nModified === 1 ? Messages.zonesafe.client.success.disableClient : Messages.zonesafe.client.error.disableClient
        });
      }
    });
  });
};


/**
 * [Listado de funciones disponibles]
 * @type {Object}
 */
var clientes = {
  "newClient": newClient,
  "allClients": allClients,
  "getInfoClient": getInfoClient,
  "disableClient": disableClient,
  "update": update,
};

module.exports = clientes;