/**
 * Cargar la cabecera principal
 */
app.directive('mainHeader', [function () {
  return {
    restrict: "AE",
    templateUrl: 'app/views/layout/header.html',
    controller: 'headerCtrl',
    controllerAs: 'self'
  };
 }]);
/**
 * Cargar menu de navegacion principal
 */
app.directive('mainNavMenu', [function () {
  return {
    restrict: "AE",
    templateUrl: 'app/views/layout/menu.html',
  };
}]);

/**
 * Validar en tiempo real los campos de un formulario
 * @type {String}
 */
app.directive('validateFormLive', [function () {
  return {
    restrict: "A",
    link: function (scope, element, attrs) {
      angular.element(element).on('change, focus', 'input, select, textarea',
        function (event) {
          return angular.element(this).parsley().validate();
        });
    },
  };
}]);

/**
 * Pasar a mayuscula contenido de inputs
 * @type {String} texto en mayuscula
 */
app.directive('inputUppercase', [function () {
  return {
    restrict: "A",
    require: "?ngModel",
    link: function (scope, element, attrs, ngModel) {
      ngModel.$parsers.push(function (input) {
        input = input ? input.toUpperCase() : "";
        return input;
      });
      element.css("text-transform", "uppercase");
    }
  };
}]);
//Verficar sesion activa
app
  .directive('checkSession', [
    '$localStorage',
    '$location',
    '_login',
    function (
      $localStorage,
      $location,
      _login) {
      return {
        restrict: "AE",
        link: function (scope, element, attrs) {
          scope.$storage = $localStorage;
          scope.verify = false;
          scope.verifySession = function () {
            if (scope.$storage.userData !== undefined) {
              _login
                .verifySession(scope.$storage.userData.user)
                .then(function successCallback (res) {
                  if (res.data === true) {
                    scope.verify = true;
                  }else{
                    scope.verify = false;
                    if(attrs.redirect !== undefined)
                      $location.path(attrs.redirect);
                  }
                }, function errorCallback (error) {
                  console.log(error);
                  scope.verify = false;
                  if(attrs.redirect !== undefined)
                    $location.path(attrs.redirect);
                });
            } else {
              scope.verify = false;
              if(attrs.redirect !== undefined)
                $location.path(attrs.redirect);
            }
          };
          scope.$on('$viewContentLoaded', function (data) {
            scope.session = false;
            scope.verifySession();
          });
          scope.$watch('$storage.userData', function (newValue, oldValue) {
            scope.session = false;
            scope.verifySession();
          });

        }
      };
  }]);

app
  .directive('logOut', [
    '$localStorage',
    '$location',
    '_login',
    function (
    $localStorage,
    $location,
    _login) {
    return {
      restrict: "AE",
      link: function (scope, element, attrs) {
        scope.$storage = $localStorage;
        scope.verify = false;

        scope.logout = function () {
          _login.logout();
          socket.emit('io-server-logout', scope.$storage.userData);
          scope.$storage.userData = undefined;
          delete scope.$storage.userData;
          $location.path("/");
        };

        element.on('click', function () {
          scope.logout();
        });

      }
    };
  }]);

app
.directive("fileread", ['Notification', function (Notification) {
  return {
    scope: {
      fileread: "=",
      ext: "="
    },
    link: function (scope, element, attributes) {
      element.bind("change", function (changeEvent) {
        var reader = new FileReader();
        reader.onload = function (loadEvent) {
          scope.$apply(function () {
            var file = {
              base64: loadEvent.target.result,
              ext: element.val().split( '.' ).pop().toLowerCase(),
              onlyName : element.val().split( '\\' ).pop().toLowerCase().split('.')[0],
              name: element.val().split( '\\' ).pop().toLowerCase(),
            };
            if(scope.ext.indexOf(file.ext) !== -1)
              scope.fileread.push(file);
            else
              Notification.warning('Error, Extencion no permitida!');
          });
        };
        reader.readAsDataURL(changeEvent.target.files[0]);
      });
    }
  };
}]);

app.directive('viewUserData', [function () {
  return {
    restrict: "A",
    scope: {
      viewUserData: "=",
      user: "=",
      names: "@"
    },
    link: function (scope, element, attributes) {
      var user = {};
      var html;
      var img
      angular.forEach(scope.viewUserData, function(value, key) {
        if(scope.user === value._id) {
          user = value;
        }
      });
      var img = (user.image != undefined && user.image != 'undefined') ? 'app/uploads/users/'+user.image : 'app/imagen/user-default.png';
      html = '<img '+
              ' class="img-circle img30_30"'+
              ' src="'+img+'"'+
              ' width="30"'+
              ' alt="Avatar"> ';
      if(scope.names !== undefined && scope.names !== null && scope.names == 'true' )
        html += '<span tooltip-placement="top" uib-tooltip="Usuario" tooltip-append-to-body="true">'+user.name +' '+user.lastname +'</span>';
      element.ready(function () {
        element.html(html);
      });
    }
  };
}]);

app
  .factory('packageJson', ['$resource', function ($resource) {
    return $resource("package.json", //la url donde queremos consumir
      {}, //aquí podemos pasar variables que queramos pasar a la consulta
      //a la función get le decimos el método, y, si es un array lo que devuelve
      { get: { method: "GET"}
    })
  }]);

//app.directive('nameUser', [function () {
//  return {
//    restrict: "A",
//    scope: {
//      nameUser: "=",
//    },
//    link: function (scope, element, attrs) {
//
//      element.on('change', function () {
//        if ((scope.nameUser.names).trim() != '' && (scope.nameUser.last_name).trim() != '') {
//          var subt_user = (scope.nameUser.names).trim().substr(0, 1).toLowerCase();
//          scope.nameUser.username = subt_user + (scope.nameUser.last_name).toLowerCase().trim().replace(/[^a-zA-Z 0-9.]+/g, ' ').split(" ")[0]
//        }
//      });
//
//
//    }
//  };
//}]);