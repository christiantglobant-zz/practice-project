module.exports = function (mongoose) {

  var Schema = mongoose.Schema;

  // Objeto modelo de Mongoose
  var contactSchema = new Schema({
    id_cliente: {
      type: mongoose.Schema.Types.ObjectId,
      required: true
    },
    nombre: {
      type: String,
    },
    telefono: {
      type: String,
    },
    correo: {
      type: String,
      index: {
        unique: true
      }
    },
    estado: {
      type: Boolean,
      default: true
    },
    fecha_registro: {
      type: Date,
      default: Date.now
    },
  });
  return mongoose.model('contact', contactSchema);
};