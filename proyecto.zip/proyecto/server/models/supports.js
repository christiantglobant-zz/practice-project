/***************************************************
 * Users
 * @package Angular
 * @author Miguel Muslaco <mjmuslaco@gmail.com>
 * @description: model de soportes
 ****************************************************/

var async = require('async');
var conect = require('../config/mongoose.js');
var Mycrypt = require('../config/crypto.js');
var Promise = require('promise');
var Messages = require('../lib/Messages.js');
var Helpers = require('../helpers/helpers.js');
var fs = require('fs');
var raiz = "app/uploads";
var folder = "tickets";

/**
 * Crear Nuevos soportes
 * @author Desarrollador02 - Miguel Muslaco
 * @param   {object}   data [Datos del soporte]
 * @returns {object}
 */
var saveSupport = function (data, user) {

  var path = raiz + "/" + folder;

  if (!fs.existsSync(raiz))
    fs.mkdirSync(raiz);
  if (!fs.existsSync(path))
    fs.mkdirSync(path);

  var attachments = data.attachments;

  return new Promise(function (resolve, reject) {
    var atta = [];
    if (attachments.length > 0) {
      attachments.forEach(function (element) {
        atta.push(Helpers.formatUrl(element.onlyName) + '.' + element.ext);
      });
    }

    global.db.supports.find({}, {
      number: 1,
      _id: 0
    }, function (error, res) {
      var auto = res.length > 0 && res.length ? (res[0].number + 1) : 1;
      var insert = new global.db.supports({
        number: auto,
        id_cliente: data.company,
        tipo: data.typeSupport,
        medio: data.medium,
        descripcion: data.description,
        responsable: data.responsible,
        id_contacto: data.mainContact,
        categoria: data.category,
        imputabilidad: data.imputability,
        prioridad: data.priority,
        asunto: data.affair,
        fecha_solicitud: new Date(data.dateRequest),
        attachments: atta,
        creado_por: user
      });

      insert.save(function (error, data) {
        if (error) {
          resolve({
            event: false,
            data: error,
            msj: error.message
          });
        } else {
          global.db.supports.aggregate([
            {
              $match: {
                _id: global.db.mongoose.Types.ObjectId(data._id)
              }
            },
            {
              $lookup: {
                from: "clientes",
                localField: "id_cliente",
                foreignField: "_id",
                as: "company"
              }
            }, {
              $lookup: {
                from: "category",
                localField: "categoria",
                foreignField: "codigo",
                as: "detailCategory"
              }
            }, {
              $lookup: {
                from: "users",
                localField: "responsable",
                foreignField: "_id",
                as: "assignedUser"
              }
          },
            {
              $sort: {
                _id: -1
              }
            }

          ], function (error, data) {
            data = data[0];
            if (error) {
              resolve({
                event: false,
                data: error,
                msj: error.message
              });
            } else {
              resolve({
                event: data._id !== undefined,
                data: data,
                msj: data._id !== undefined ? Messages.zonesafe.tickets.success.new : Messages.zonesafe.tickets.error.new
              });
            }
          });

          if (!fs.existsSync(path + '/' + data._id))
            fs.mkdirSync(path + '/' + data._id);

          if (attachments.length > 0) {
            attachments.forEach(function (element) {
              var base64 = element.base64.split('base64,').pop();
              fs.writeFile(path + '/' + data._id + "/" + Helpers.formatUrl(element.onlyName) + '.' + element.ext, base64, {
                encoding: 'base64'
              }, function (err) {
                console.log(err);
              });
            });
          }
        }
      });
    }).limit(1).sort({
      number: -1
    });
  });
};

/**
 * Guardar la respuesta del soporte
 * @author Desarrollador02 - Miguel Muslaco
 * @param   {object}   data [Datos de respuesta del soporte]
 * @returns {object}
 */
var newSupportDetalls = function (datas, user) {

  var path = raiz + "/" + folder;
  var attachments = datas.attachments;

  var atta = [];
  if (attachments.length > 0) {
    attachments.forEach(function (element) {
      atta.push(Helpers.formatUrl(element.onlyName) + '.' + element.ext);
    });
  }

  var insert = new global.db.supportsDetail({
    sticker: datas.sticker,
    user: datas.username,
    respuesta: datas.response,
    attachments: atta
  });
  return new Promise(function (resolve, reject) {
    insert.save(function (error, data) {
      if (error) {
        resolve({
          event: false,
          data: error,
          msj: error.message
        });
      } else {
        if (data._id !== undefined)
          sendLog(datas.sticker, "Respuesta", datas.response, datas.username);

        if (!fs.existsSync(path + '/' + datas.sticker))
          fs.mkdirSync(path + '/' + datas.sticker);

        if (!fs.existsSync(path + '/' + datas.sticker + '/response'))
          fs.mkdirSync(path + '/' + datas.sticker + '/response');

        if (attachments.length > 0) {
          attachments.forEach(function (element) {
            var base64 = element.base64.split('base64,').pop();
            fs.writeFile(path + '/' + datas.sticker + "/response/" + Helpers.formatUrl(element.onlyName) + '.' + element.ext, base64, {
              encoding: 'base64'
            }, function (err) {
              console.log(err);
            });
          });
        }

        resolve({
          event: data._id !== undefined,
          data: data,
          msj: data._id !== undefined ? Messages.zonesafe.tickets.success.response : Messages.zonesafe.tickets.error.response
        });
      }
    });
  });
};
/**
 * Nuevo contacto para la empresa
 * @author Desarrollador02 - Miguel Muslaco
 * @param   {object}   data [Datos de la empresa]
 * @returns {object}
 */
var newConct = function (data) {
  var insert = new global.db.contact({
    id_cliente: data.company,
    nombre: data.fullname,
    telefono: data.phones,
    correo: data.email
  });
  return new Promise(function (resolve, reject) {
    insert.save(function (error, data) {
      if (error) {
        resolve({
          event: false,
          msj: error.message
        });
      } else {
        resolve({
          event: data._id !== undefined,
          data: data,
          msj: data._id !== undefined ? Messages.zonesafe.tickets.success.newConct : Messages.zonesafe.tickets.error.newConct
        });
      }
    });
  });
};

/**
 * Listar todos los usuarios del sistema
 * @author Desarrollador02 - Miguel Muslaco
 * @returns {object} [Datos del soportes]
 */
var allSupport = function () {
  return new Promise(function (resolve, reject) {
    global.db.supports.aggregate(
      [{
          $match: {
            estado: {
              $ne: 'CONFIRMADO'
            }
          }
      },
        {
          $lookup: {
            from: "clientes",
            localField: "id_cliente",
            foreignField: "_id",
            as: "company"
          }
        }, {
          $lookup: {
            from: "category",
            localField: "categoria",
            foreignField: "codigo",
            as: "detailCategory"
          }
        }, {
          $lookup: {
            from: "users",
            localField: "responsable",
            foreignField: "_id",
            as: "assignedUser"
          }
        },
        {
          $sort: {
            _id: -1
          }
        }
    ],
      function (error, data) {
        if (error) {
          reject({
            event: false,
            data: error,
            msj: Messages.global.error.error
          });
        } else {
          resolve({
            event: data.length > 0,
            data: data,
            msj: data.length ? Messages.zonesafe.tickets.success.allstickers : Messages.zonesafe.tickets.error.allstickers
          });
        }
      });
  });
};


/**
 * Listar historial de sopotes
 * @method getHistory
 * @return {[type]} [description]
 */
var getHistory = function () {
  return new Promise(function (resolve, reject) {
    global.db.supports.aggregate(
      [{
          $match: {
            estado: 'CONFIRMADO'
          }
      },
        {
          $lookup: {
            from: "clientes",
            localField: "id_cliente",
            foreignField: "_id",
            as: "company"
          }
        }, {
          $lookup: {
            from: "category",
            localField: "categoria",
            foreignField: "codigo",
            as: "detailCategory"
          }
        }, {
          $lookup: {
            from: "users",
            localField: "responsable",
            foreignField: "_id",
            as: "assignedUser"
          }
        }, {
          $sort: {
            _id: 1
          }
        }
    ],
      function (error, data) {
        if (error) {
          reject({
            event: false,
            data: error,
            msj: Messages.global.error.error
          });
        } else {
          resolve({
            event: data.length > 0,
            data: data,
            msj: data.length ? Messages.zonesafe.tickets.success.allstickers : Messages.zonesafe.tickets.error.allstickers
          });
        }
      });
  });
};

/**
 * Informacion basica de soportes
 * @author Desarrollador02 - Miguel Muslaco
 * @param   {number} idem [Numero del sticker]
 * @returns {object}
 */
var infoTickets = function (idem) {
  var idem = parseInt(idem);
  return new Promise(function (resolve, reject) {
    global.db.supports.aggregate([
      {
        $match: {
          number: idem
        }
    },
      {
        $lookup: {
          from: "clientes",
          localField: "id_cliente",
          foreignField: "_id",
          as: "applicant"
        }
      },
      {
        $lookup: {
          from: "contacts",
          localField: "id_contacto",
          foreignField: "_id",
          as: "userContacts"
        }
      },
      {
        $lookup: {
          from: "users",
          localField: "creado_por",
          foreignField: "_id",
          as: "created_by"
        }
      }, {
        $lookup: {
          from: "category",
          localField: "categoria",
          foreignField: "codigo",
          as: "nameCategoria"
        }
      }, {
        $lookup: {
          from: "users",
          localField: "responsable",
          foreignField: "_id",
          as: "assigned_user"
        }
      }
    ], function (error, data) {
      if (error) {
        reject({
          event: false,
          data: error
        });
      } else {
        if (data !== null)
          resolve({
            event: true,
            data: data
          });
      }
    });
  });
};
/**
 * [[Description]]
 * @author Desarrollador02 - Miguel Muslaco
 * @param   {[[Type]]} idem [[Description]]
 * @returns {[[Type]]} [[Description]]
 */
var getresponse = function (idem) {
  return new Promise(function (resolve, reject) {
    global.db.supportsDetail.aggregate([
      {
        $match: {
          sticker: global.db.mongoose.Types.ObjectId(idem)
        }
      },
      {
        $lookup: {
          from: "users",
          localField: "user",
          foreignField: "_id",
          as: "assigned_users"
        }
      }
    ], function (error, data) {
      if (error) {
        reject({
          event: false,
          data: error
        });
      } else {
        if (data !== null)
          resolve({
            event: true,
            data: data
          });
      }
    });
  });
};

/**
 * Listar todos los clientes disponibles
 * @author Desarrollador02 - Miguel Muslaco
 * @returns {object} [Datos del clientes]
 */
var allClientes = function () {

  return new Promise(function (resolve, reject) {
    global.db.clientes.find({
      estado: true
    }, function (error, data) {
      if (error) {
        reject({
          event: false,
          data: error
        });
      } else {
        if (data !== null)
          resolve({
            event: true,
            data: data
          });
      }
    }).sort({
      razon_social: 1
    });
  });
};
/**
 * Listar todos los contacto para una empresa especifica
 * @author Desarrollador02 - Miguel Muslaco
 * @param   {object}   data [Listar Todos los contacto]
 * @returns {object}
 */
var getContactComp = function (data) {
  return new Promise(function (resolve, reject) {
    global.db.contact.find({
      id_cliente: data.id,
      estado: true
    }, function (error, data) {
      if (error) {
        reject({
          event: false,
          data: error,
          msj: Messages.global.error.error
        });
      } else {
        resolve({
          event: data.length > 0,
          data: data,
          msj: data.length ? Messages.zonesafe.tickets.success.AllContactComp : Messages.zonesafe.tickets.error.AllContactComp
        });
      }
    });
  });
};
/**
 * Listar la informacion del soporte a actualizar
 * @author Desarrollador02 - Miguel Muslaco
 * @param   {object} idem [Datos del soporte]
 * @returns {object}
 */
var infoTicketsEdits = function (idem) {
  return new Promise(function (resolve, reject) {
    global.db.supports.findOne({
      number: idem
    }, function (error, data) {
      if (error) {
        reject({
          event: false,
          data: error,
          msj: Messages.global.error.error
        });
      } else {
        resolve({
          event: data.length > 0,
          data: data,
          msj: data.length ? Messages.zonesafe.tickets.success.AllContactComp : Messages.zonesafe.tickets.error.AllContactComp
        });
      }
    });
  });
};

/**
 * Cambiar estado de un ticket
 * @method changeStatusTicket
 * @param  {object} user [Datos del usuario]
 * @return {Promise}
 */
var changeStatusTicket = function (ticket, user) {

  return new Promise(function (resolve, reject) {
    global.db.supports.update({
      _id: ticket.ticket,
      estado: {
        $ne: 'CONFIRMADO'
      }
    }, {
      estado: ticket.status,
      confirm_date: new Date()
    }, function (error, data) {
      if (error) {
        reject({
          event: false,
          data: error,
          msj: error.message
        });
      } else {
        if (data.nModified === 1)
          sendLog(ticket.ticket, "Cambio de estado", ticket.status, user._id);
        resolve({
          event: data.nModified === 1,
          data: data,
          msj: data.nModified === 1 ? Messages.zonesafe.tickets.success.changeStatus : Messages.zonesafe.tickets.error.changeStatus
        });
      }
    });
  });
};

/**
 * Actualiza el usuario
 * @author Desarrollador02 - Miguel Muslaco
 * @param   {object}   ticket [Datos del usuario]
 * @returns {object}
 */
var changeUserTicket = function (ticket) {

  return new Promise(function (resolve, reject) {
    global.db.supports.update({
      _id: ticket.ticket,
      estado: {
        $ne: 'CONFIRMADO'
      }
    }, {
      responsable: global.db.mongoose.Types.ObjectId(ticket.user),
      confirm_date: new Date()
    }, function (error, data) {
      if (error) {
        reject({
          event: false,
          data: error,
          msj: error.message
        });
      } else {
        resolve({
          event: data.nModified === 1,
          data: data,
          msj: data.nModified === 1 ? Messages.zonesafe.tickets.success.changeStatusUser : Messages.zonesafe.tickets.error.changeStatusUser
        });
      }
    });
  });
};

var changePriority = function (ticket) {
  var msj = "",
    action;
  return new Promise(function (resolve, reject) {
    global.db.supports.update({
      _id: global.db.mongoose.Types.ObjectId(ticket.ticket)
    }, {
      prioridad: ticket.priority
    }, function (error, data) {
      if (error) {
        reject({
          event: false,
          data: error,
          msj: error.message
        });
      } else {
        if (data.n == 1 && data.nModified == 1 && data.ok == 1) {
          msj = Messages.zonesafe.tickets.success.changePriority;
          action = "success";
        } else if (data.n == 1 && data.nModified == 0 && data.ok == 1) {
          msj = Messages.zonesafe.tickets.success.changePriorityNot;
          action = "warning";
        } else {
          msj = Messages.zonesafe.tickets.error.changePriority;
          action = "danger";

        }
        resolve({
          event: data.nModified === 1,
          data: data,
          msj: msj,
          action: action
        });
      }
    });
  });
};

/**
 * Actualizo informacion de soporte
 * @author Desarrollador02 - Miguel Muslaco
 * @param   {object}   suport [Datos de soportes]
 * @returns {object}
 */
var updateSupport = function (suport) {
  return new Promise(function (resolve, reject) {
    global.db.supports.update({
      _id: suport._id,
      estado: {
        $ne: 'CONFIRMADO'
      }
    }, {
      tipo: suport.typeSupport,
      medio: suport.medium,
      descripcion: suport.description,
      responsable: suport.responsible,
      id_contacto: suport.mainContact,
      categoria: suport.category,
      imputabilidad: suport.imputability,
      prioridad: suport.priority,
      asunto: suport.affair,
    }, function (error, data) {
      if (error) {
        reject({
          event: false,
          data: error,
          msj: error.message
        });
      } else {
        resolve({
          event: data.nModified === 1,
          data: data,
          msj: data.nModified === 1 ? Messages.zonesafe.tickets.success.update : Messages.zonesafe.tickets.error.update
        });
      }
    });
  });
};

/**
 * Listar el total de soportes registrados
 * @method getTotalSuports
 * @return {Promise}
 */
var getTotalSuports = function () {
  return new Promise(function (resolve, reject) {
    global.db.supports.aggregate(
      [{
          $lookup: {
            from: "clientes",
            localField: "id_cliente",
            foreignField: "_id",
            as: "company"
          }
        }, {
          $lookup: {
            from: "category",
            localField: "categoria",
            foreignField: "codigo",
            as: "detailCategory"
          }
        }, {
          $lookup: {
            from: "users",
            localField: "responsable",
            foreignField: "_id",
            as: "assignedUser"
          }
        },
        {
          $sort: {
            _id: -1
          }
        }
    ],
      function (error, data) {
        if (error) {
          reject({
            event: false,
            data: error,
            msj: Messages.global.error.error
          });
        } else {
          resolve({
            event: data.length > 0,
            data: data,
            msj: data.length ? Messages.zonesafe.tickets.success.allstickers : Messages.zonesafe.tickets.error.allstickers
          });
        }
      });
  });
};
var getTotalSuportsMeses = function () {
  return new Promise(function (resolve, reject) {
    global.db.supports.aggregate([
        {
          $group: {
            _id: {
              month: {
                $month: "$fecha_registro"
              },
              year: {
                $year: "$fecha_registro"
              }
            },
            status: {
              $push: "$estado"
            },
            count: {
              $sum: 1
            }
          }
      }
        ],
      function (error, data) {
        if (error) {
          reject({
            event: false,
            data: error,
            msj: Messages.global.error.error
          });
        } else {
          resolve({
            event: data.length > 0,
            data: data,
            msj: data.length ? Messages.zonesafe.tickets.success.allstickers : Messages.zonesafe.tickets.error.allstickers
          });
        }
      });
  });
};
var getTotalSuportsResult = function (dates) {
  return new Promise(function (resolve, reject) {
    global.db.supports.aggregate(
      [
        {
          $match: {
            fecha_registro: {
              "$gte": new Date(dates.init + " 00:00:00 GMT-0500"),
              "$lte": new Date(dates.finis + " 00:00:00 GMT-0500")
            }
          }
            },
        {
          $lookup: {
            from: "users",
            localField: "responsable",
            foreignField: "_id",
            as: "assignedUser"
          }
        },
        {
          $sort: {
            _id: -1
          }
        }
    ],
      function (error, data) {
        if (error) {
          reject({
            event: false,
            data: error,
            msj: Messages.global.error.error
          });
        } else {
          resolve({
            event: data.length > 0,
            data: data,
            msj: data.length ? Messages.zonesafe.tickets.success.allstickers : Messages.zonesafe.tickets.error.allstickers
          });
        }
      });
  });
};

/**
 * Actualizar los usuarios para compartie ticket
 * @method
 * @param  {object} tickect [Datos del ticket]
 * @param  {object} user    [Datos de sesion]
 * @return {Promise}
 */
var updateShareTicket = function (tickect, user) {
  return new Promise(function (resolve, reject) {
    global.db.supports.update({
      _id: tickect._id
    }, {
      share: tickect.share
    }, function (error, data) {
      if (error) {
        reject({
          event: false,
          data: error,
          msj: error.message
        });
      } else {
        resolve({
          event: data.nModified === 1,
          data: data,
          msj: data.nModified === 1 ? Messages.zonesafe.tickets.success.updateShare : Messages.zonesafe.tickets.error.updateShare
        });
      }
    });
  });
};

var sendLog = function (ticket, action, data, by) {
  var insert = new global.db.log_supports({
    ticket: ticket,
    action: action,
    data: data,
    by: by
  });
  insert.save(function (error, data) {});
};

/**
 * Cargar cambios de los casos que estoy asignado
 * @method loadChanges
 * @param  {String} user [Id del usuario]
 * @return {Promise}
 */
var loadChanges = function (user) {
  return new Promise(function (resolve, reject) {
    global.db.log_supports.aggregate([
        {
          $match: {
            "viewed": {
              $nin: [user]
            }
          }
      },
        {
          $lookup: {
            from: "supports",
            localField: "ticket",
            foreignField: "_id",
            as: "info"
          }
      },
        {
          $sort: {
            _id: 1
          }
        }, {
          $unwind: "$info"
      }, {
          $match: {
            $or: [
              {
                "info.responsable": global.db.mongoose.Types.ObjectId(user)
              },
              {
                "info.share": {
                  $in: [user]
                }
              }
          ],
            "info": {
              $ne: []
            },
          }
      }],
      function (error, data) {
        if (error) {
          reject({
            event: false,
            data: error,
            msj: error.message
          });
        } else {
          resolve({
            event: data.length > 0,
            data: data,
            msj: data.length ? Messages.zonesafe.logs.success.loadChanges : Messages.zonesafe.logs.error.loadChanges
          });
        }
      });
  });

};

/**
 * Marr como visto
 * @method
 * @param  {[type]} inbox [description]
 * @param  {[type]} user  [description]
 * @return {[type]}       [description]
 */
var markViewed = function (inbox, user) {

  var ors = [];

  inbox.forEach(function (element) {
    ors.push({
      _id: global.db.mongoose.Types.ObjectId(element)
    });
  });

  return new Promise(function (resolve, reject) {
    global.db.log_supports.update({
      $or: ors,
      $and: [
        {
          "viewed": {
            $nin: [user]
          }
          }
        ]
    }, {
      "$push": {
        "viewed": user
      }
    }, {
      multi: true
    }, function (error, data) {
      if (error) {
        reject({
          event: false,
          data: error,
          msj: error.message
        });
      } else {
        resolve({
          event: data.nModified >= 1,
          data: data,
          msj: data.nModified >= 1 ? Messages.zonesafe.tickets.success.markViewed : Messages.zonesafe.tickets.error.markViewed
        });
      }
    });
  });
};

/**
 * [Listado de funciones disponibles]
 * @type {Object}
 */
var supports = {
  "saveSupport": saveSupport,
  "allSupport": allSupport,
  "allClientes": allClientes,
  "newSupportDetalls": newSupportDetalls,
  "infoTickets": infoTickets,
  "getresponse": getresponse,
  "newConct": newConct,
  "getContactComp": getContactComp,
  "changeStatusTicket": changeStatusTicket,
  "getHistory": getHistory,
  "infoTicketsEdits": infoTicketsEdits,
  "updateSupport": updateSupport,
  "getTotalSuports": getTotalSuports,
  "updateShareTicket": updateShareTicket,
  "sendLog": sendLog,
  "loadChanges": loadChanges,
  "changeUserTicket": changeUserTicket,
  "markViewed": markViewed,
  "changePriority": changePriority,
  "getTotalSuportsMeses": getTotalSuportsMeses,
  "getTotalSuportsResult": getTotalSuportsResult,
};

module.exports = supports;
