/***************************************************
 * profileCtrl
 * @package JS
 * @author Naycool Gonzalez <naycoolgonzalez@gmail.com>  Developer web
 * @description: Controlador para administar usuarios principal
 *
 *****************************************************/

app.controller('profileCtrl', [
	'$localStorage',
	'$filter',
	'$scope',
	'ngProgressFactory',
	'Notification',
	'_cropper',
	'_users',
	function (
		$localStorage,
		$filter,
		$scope,
		ngProgressFactory,
		Notification,
		_cropper,
		_users)	{

		var self = this;

		$scope.user = angular.copy(_users.user);
		$scope.$storage = $localStorage;
		$scope.userData = $scope.$storage.userData;
		$scope.updateData = angular.copy($scope.userData);
		$scope.progressbar = ngProgressFactory.createInstance();
		$scope.cropper = _cropper;
		this.configPhoto = angular.copy(_users.configPhoto);
		$scope.updateData.imageUpdate = false;

		/**
		 * Recortar imagen
		 * @method _cut
		 * @param  {String} instance [Id de la imagen]
		 */
		this._cut = function (instance) {
			$scope.updateData.image = $scope.cropper.cut(
				instance,
				self.configPhoto._sizes.cover.width,
				self.configPhoto._sizes.cover.height
			);
			$scope.updateData.imageUpdate = true;
		};


		/**
		 * Actualizar datos del usuario
		 * @method updateUser
		 * @param  {event} eve
		 */
		$scope.updateUser = function (eve) {
			eve.preventDefault();
			var form = eve.target;
			if (angular.element(form).parsley().validate()) {
				$scope.progressbar.start();
				$scope.save = !$scope.save;
				_users.update($scope.updateData)
					.then(function successCallback(res) {
						$scope.save = !$scope.save;
						if(res.data.data.nModified) {
							$scope.updateData.imageUpdate = false;
							$scope.updateData.image = res.data.data.img;
							$scope.$storage.userData = angular.copy($scope.updateData);
							$scope.$storage.userData.image = res.data.data.img;
						}
						Notification({
							message: res.data.msj,
							replaceMessage: true
						}, res.data.event ? 'success' : 'error');
						$scope.progressbar.complete();
					}, function errorCallback(data) {
						$scope.progressbar.complete();
						$scope.save = !$scope.save;
						Notification.error("Se ha producido un error, Por favor intente nuevamente");
					});
			} else {
				Notification.warning('Ingrese los dato del formulario y reintente');
			}
		};

		/**
		 * Actualizar contraseña
		 * @method changePassword
		 * @param  {event} eve
		 */
		$scope.changePassword = function (eve) {
			eve.preventDefault();
			var form = eve.target;
			if (angular.element(form).parsley().validate()) {
				$scope.progressbar.start();
				$scope.save = !$scope.save;
				_users.changePassword($scope.password)
					.then(function successCallback(res) {
						$scope.save = !$scope.save;
						Notification({
							message: res.data.msj,
							replaceMessage: true
						}, res.data.event ? 'success' : 'error');
						$scope.progressbar.complete();
					}, function errorCallback(data) {
						$scope.progressbar.complete();
						$scope.save = !$scope.save;
						Notification.error("Se ha producido un error, Por favor intente nuevamente");
					});
			} else {
				Notification.warning('Ingrese los dato del formulario y reintente');
			}
		};

		$scope.$watch('$storage.userData', function (newValue, oldValue) {
			$scope.userData = newValue;
		});
}]);
