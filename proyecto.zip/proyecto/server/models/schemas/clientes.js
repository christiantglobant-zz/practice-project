/**
 * Estructura de la tabla de clientes
 * @author Desarrollador02 - Miguel Muslaco
 * @param   {object}   mongoose
 * @returns {object}
 */
module.exports = function (mongoose) {

  var Schema = mongoose.Schema;

  // Objeto modelo de Mongoose
  var clienteSchema = new Schema({

    identificacion: {
      type: String,
    },
    digito_verif: {
      type: Number,
      required: true
    },
    razon_social: {
      type: String,
      required: true
    },
    nomb_comercial: {
      type: String,
      required: true
    },
    celular: {
      type: String,
      required: true
    },
    email: {
      type: String,
      required: true
    },
    image: {
      type: String,
      default: "undefined"
    },
    estado: {
      type: Boolean,
      default: true
    },
    ultima_actualizacion: {
      type: Date
    },
    fecha_registro: {
      type: Date,
      default: Date.now
    },
  });


  return mongoose.model('clientes', clienteSchema);
};