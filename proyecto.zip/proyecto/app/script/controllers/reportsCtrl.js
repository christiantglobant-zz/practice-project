/***************************************************
 * Cpanel Controller
 * @package Angular
 * @author Naycool Gonzalez <naycoolgonzalez@gmail.com>
 ****************************************************/

app.controller('reportsCtrl', [
'$scope',
'$log',
'$location',
'$localStorage',
'$timeout',
'$filter',
'Notification',
'ngProgressFactory',
'_support',
'_users',
function (
    $scope,
    $log,
    $location,
    $localStorage,
    $timeout,
    $filter,
    Notification,
    ngProgressFactory,
    _support,
    _users) {

    /** instancia de este controlador **/
    var self = this;
    $scope.reload = false;
    $scope.$storage = $localStorage;
    $scope.userData = $scope.$storage.userData;

    /** Estados disponibles **/
    $scope.status = ['NUEVO', 'EN PROCESO', 'EN ESPERA', 'CERRADO', 'CONFIRMADO', 'CANCELADO'];
    $scope.prioridad = ['BAJO', 'MEDIO', 'ALTO'];

    $scope.search = {
      estado: '',
      assigned: '',
    };
    $scope.typesCategory = angular.copy(_support.typesCategory);
    $scope.currentDateInit = $filter('date')(new Date(), 'yyyy-MM-dd');
    $scope.currentDateFinis = $scope.currentDateInit;

    /** Listar todos los usuarios **/
    this.allUsuarios = [];

    /** User lista de soportes **/
    this.listUsers = [];

    this.allSoports = [];
    this.allSoportsMese = [];

    $scope.update = false;
    /** Cantidad de registro a mostrar**/
    $scope.showCant = "10";

    /** Configuración de mensaje de precarga **/
    $scope.configMsj = {
      delay: 0,
      minDuration: 0,
      message: 'Cargando datos...',
      backdrop: true,
      promise: null
    };

    self.icons = {
      'all': {
        "icon": 'fa-ticket',
        "color": "rgb(255, 156, 0)"
      },
      "NUEVO": {
        "icon": 'fa-plus',
        "color": "silver"
      },
      "EN PROCESO": {
        "icon": 'fa-spinner',
        "color": "rgb(51, 122, 183)"
      },
      "EN ESPERA": {
        "icon": 'fa-clock-o',
        "color": "orange"
      },
      "CERRADO": {
        "icon": 'fa-minus-square',
        "color": "black"
      },
      "CONFIRMADO": {
        "icon": 'fa-check',
        "color": "rgb(92, 184, 92)"
      },
      "CANCELADO": {
        "icon": 'fa-times',
        "color": "red"
      }
    };

    /**
     * Opciones para el carousel
     * @type {Object}
     */
    self.owlOptions = {
      loop: false,
      nav: false,
      margin: 0,
      items: 4,
      autoplay: true,
      autoplayTimeout: 5000,
      autoplayHoverPause: true,
      animateOut: 'fadeOut',
      animateIn: 'fadeIn',
    };

    /**
     * Filtar
     * @author Desarrollador02 - Miguel Muslaco
     * @param {[[Type]]} filter [[Description]]
     * @param {[[Type]]} value  [[Description]]
     */
    $scope.filter = function (filter, value) {
      $scope.search[filter] = value;
    };

    /**
     * Listar todos los soportes del sistema
     * @author Desarrollador02 - Miguel Muslaco
     * @returns {object} [Datos del soportes]
     */
    this.getTotalSuports = function () {
      $scope.configMsj.promise = _support.getTotalSuports()
        .then(function (data) {
          self.allSoports = data.data.data;
        }).catch(function (erro) {
          Notification.warning('¡Error! Por favor intente nuevamente!');
        });
    };
    $scope.meses = ["", "ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO", "JUNIO", "JULIO", "AGOSTO", "SEPTIEMBRE", "OCTUBRE", "NOVIEMBRE", "DICIEMBRE"];

    this.getTotalSuportsMeses = function () {
      return _support.getTotalSuportsMeses()
        .then(function (data) {
          angular.forEach(data.data.data, function (value, key) {
            value.mes = $scope.meses[value._id.month];
            value.anno = value._id.year;
          });
          self.allSoportsMese = data.data.data;
        }).catch(function (erro) {
          Notification.warning('¡Error! Por favor intente nuevamente!');
        });
    };
    /**
     * Listar todos los soportes del sistema
     * @author Desarrollador02 - Miguel Muslaco
     */
    this.getTotalSuportsResult = function () {
      return _support.getTotalSuportsResult($scope.currentDateInit, $scope.currentDateFinis)
        .then(function (data) {
          self.allSoports = data.data.data;
          angular.forEach(self.allSoports, function (value, key) {
            value.assignedUser[0].estado = value.estado;
            self.listUsers.push(value.assignedUser[0]);
          });
          self.getUsuarios();
        }).catch(function (erro) {
          Notification.warning('¡Error! Por favor intente nuevamente!');
        });
    };

    /**  Se vigila las fechas de inicio y final **/
    $scope.$watch('[currentDateInit, currentDateFinis]', function (newValue, oldValue) {
      if (new Date($scope.currentDateFinis) >= new Date($scope.currentDateInit)) {
        if (newValue[0] !== undefined && newValue[0] !== "" && newValue[1] !== undefined && newValue[1] !== "") {
          return _support.getTotalSuportsResult($scope.currentDateInit, $scope.currentDateFinis)
            .then(function (data) {
              if (data.data.event) {
                self.allSoports = data.data.data;
                self.listUsers = [];
                angular.forEach(self.allSoports, function (value, key) {
                  value.assignedUser[0].estado = value.estado;
                  self.listUsers.push(value.assignedUser[0]);
                });
                self.getUsuarios();
              } else {
                $scope.myChartObject.data.rows = [];
                $scope.myChartObject2.data.rows = [];
                $scope.myChartPie2Object.data.rows = [];
                $scope.myChartPie3Object.data.rows = [];
              }
            }).catch(function (erro) {
              Notification.warning('¡Error! Por favor intente nuevamente!');
            });
        } else {
          Notification.warning('¡Error! Por favor intente nuevamente!');
        }
      } else {
        Notification.warning('¡La fecha de final no puede ser menor a la fecha de inicio!');
      }
    });

    /** Configuracion del reportes **/
    $scope.myChartObject = {
      type: "ColumnChart",
      options: {
        "title": "Numero total de ticket de usuarios",
        "isStacked": "true",
        legend: {
          position: 'top'
        },
        "colors": ['#23AE89', '#1C7EBB', '#a39f9f', '#E94B3B', '#FFB61C'],
        "fill": 10,
        "displayExactValues": true,
        "vAxis": {
          "title": "Número de tickets",
        },

      },
      data: {
        cols: [
          {
            id: "t",
            label: "Topping",
            type: "string",
        },
          {
            id: "z",
            label: "Solucionado",
            type: "number"
        },
          {
            id: "g",
            label: "En gestión",
            type: "number"
        },

      ],
        rows: []
      }
    };

    /**
     * Configuracion de la grafica dos
     * de ver todos los estados de los soportes
     **/
    $scope.myChartObject2 = {
      type: "ColumnChart",
      options: {
        "title": "Ticket por gestión",
        "isStacked": "false",
        legend: {
          position: 'top'
        },
        "colors": ['#c0c0c0', '#337ab7', '#ffa500', '#d9534f', '#5cb85c'],
        "fill": 10,
        "displayExactValues": true,
        "vAxis": {
          "title": "Número de tickets",
        },

      },
      data: {
        cols: [
          {
            id: "t",
            label: "Topping",
            type: "string",
        },
          {
            id: "z",
            label: "Nuevo",
            type: "number"
        },
          {
            id: "g",
            label: "En proceso",
            type: "number"
        },
          {
            id: "ep",
            label: "En espera",
            type: "number"
        },
          {
            id: "c",
            label: "Cerrado",
            type: "number"
        },
          {
            id: "c",
            label: "Confirmado",
            type: "number"
        },
        ],
        rows: []
      }
    };
    /*****************Datos 3************/
    $scope.myChartObject3 = {
      type: "ColumnChart",
      options: {
        "title": "Soportes por Mes - Vulcano",
        "isStacked": "false",
        legend: {
          position: 'top'
        },
        "colors": ['#1C7EBB', '#23AE89', '#a39f9f', '#E94B3B', '#FFB61C'],
        "fill": 10,
        "displayExactValues": true,
        "vAxis": {
          "title": "Número de Casos",
        },

      },
      data: {
        cols: [
          {
            id: "t",
            label: "Topping",
            type: "string",
        },
          {
            id: "z",
            label: "Ingresados",
            type: "number"
        },
          {
            id: "g",
            label: "Atendidos",
            type: "number"
        },
          {
            id: "p",
            label: "Pendientes",
            type: "number"
        },

      ],
        rows: []
      }
    };
    $scope.myChartPieObject = {
      type: "PieChart",
      options: {
        "title": "",
        "isStacked": "true",
        "colors": ['#1C7EBB', '#FFB61C', '#23AE89'],
        "displayExactValues": true,
      },
      data: {
        cols: [
          {
            id: "t",
            label: "Topping",
            type: "string"
        },
          {
            id: "rs",
            label: "Alta",
            type: "number",
        },
          {
            id: "z",
            label: "Media",
            type: "number"
        },
          {
            id: "s",
            label: "Baja",
            type: "number"
        },
      ],
        rows: []
      }
    };

    $scope.myChartPie2Object = {
      type: "PieChart",
      options: {
        "title": "",
        "isStacked": "true",
        "colors": ['#5bc0de', '#FFB61C', '#d9534f'],
        "displayExactValues": true,
      },
      data: {
        "cols": [
          {
            id: "t",
            label: "Topping",
            type: "string"
        },
          {
            id: "rs",
            label: "Alta",
            type: "number",
        },
          {
            id: "z",
            label: "Media",
            type: "number"
        },
          {
            id: "s",
            label: "Baja",
            type: "number"
        },
      ],
        rows: []
      }
    };

    $scope.myChartPie3Object = {
      type: "PieChart",
      options: {
        "title": "",
        "isStacked": "true",
        "colors": ['#777', '#337ab7', '#5bc0de', '#d9534f', '#5cb85c', '#23AE89'],
        "displayExactValues": true,
      },
      data: {
        "cols": [
          {
            id: "t",
            label: "Topping",
            type: "string"
        },
          {
            id: "rs",
            label: "Alta",
            type: "number",
        },
          {
            id: "z",
            label: "Media",
            type: "number"
        },
          {
            id: "s",
            label: "Baja",
            type: "number"
        },
      ],
        "rows": []
      },

    };

    this.getUsuarios = function () {
      $scope.update = true;
      return _users.getAllusers().then(function (res) {
        if (res.data.event && res.data.data.length) {
          self.allUsuarios = res.data.data;
          $scope.myChartObject.data.rows = [];
          $scope.myChartObject2.data.rows = [];
          $scope.myChartObject3.data.rows = [];
          $scope.myChartPie2Object.data.rows = [];
          $scope.myChartPie3Object.data.rows = [];
          var cant = 0;

          angular.forEach(self.allUsuarios, function (value, key) {


            var recibidos = $filter('filter')(self.listUsers, {
              email: value.email
            }, true).length;

            var cerrado = $filter('filter')(self.listUsers, {
              email: value.email,
              estado: "CERRADO"
            }, true).length;

            var confirmado = $filter('filter')(self.listUsers, {
              email: value.email,
              estado: "CONFIRMADO"
            }, true).length;

            var nuevo = $filter('filter')(self.listUsers, {
              email: value.email,
              estado: "NUEVO"
            }, true).length;

            var proceso = $filter('filter')(self.listUsers, {
              email: value.email,
              estado: "EN PROCESO"
            }, true).length;

            var espera = $filter('filter')(self.listUsers, {
              email: value.email,
              estado: "EN ESPERA"
            }, true).length;

            cant = nuevo + proceso + espera;

            var datas = {
              c: [
                {
                  v: value.name
                }
                ,
                {
                  v: (confirmado + cerrado)
                },
                {
                  v: cant
                },
              ]
            };
            var datas2 = {
              c: [
                {
                  v: value.name.split(" ")[0]
                }
                ,
                {
                  v: nuevo
                },
                {
                  v: proceso
                },
                {
                  v: espera
                },
                {
                  v: cerrado
                },
                {
                  v: confirmado
                }
              ]
            };
            if (recibidos > 0 && cant > 0) {
              $scope.myChartObject.data.rows.push(datas);
              $scope.myChartObject2.data.rows.push(datas2);
            }
          });

          $scope.myChartPieObject.data.rows = [{
              c: [
                {
                  v: "Correo"
              },
                {
                  v: $filter('filter')(self.allSoports, {
                    medio: "Correo"
                  }, true).length
              },
            ]
          },
            {
              c: [
                {
                  v: "Llamada"
              },
                {
                  v: $filter('filter')(self.allSoports, {
                    medio: "LLamada"
                  }, true).length
              }
          ]
          },
            {
              c: [
                {
                  v: "Queja"
              },
                {
                  v: $filter('filter')(self.allSoports, {
                    medio: "Queja"
                  }, true).length
            },
          ]
          }];

          angular.forEach($scope.prioridad, function (value, key) {
            var datas = {
              c: [
                {
                  v: value
                },
                {
                  v: $filter('filter')(self.allSoports, {
                    prioridad: value
                  }, true).length
                }
            ]
            };
            $scope.myChartPie2Object.data.rows.push(datas);
          });


          angular.forEach($scope.status, function (value, key) {
            var datas = {
              c: [
                {
                  v: value
                },
                {
                  v: $filter('filter')(self.allSoports, {
                    estado: value
                  }, true).length
                }
            ]
            };
            $scope.myChartPie3Object.data.rows.push(datas);
          });






          angular.forEach($scope.meses, function (value, key) {

            var cantidad = $filter('filter')(self.allSoportsMese, {
              mes: value
            }, true);

            cantidad = cantidad.length > 0 ? cantidad[0].count : 0;

            var confirmado = $filter('filter')(self.allSoportsMese, {
              mes: value,
            }, true);

            confirmado = confirmado.length > 0 ? $filter('filter')(confirmado[0].status, 'CONFIRMADO').length : 0;

            var cerrado = $filter('filter')(self.allSoportsMese, {
              mes: value,
            }, true);

            cerrado = cerrado.length > 0 ? $filter('filter')(cerrado[0].status, 'CERRADO').length : 0;

            var nuevo = $filter('filter')(self.allSoportsMese, {
              mes: value,
            }, true);
            nuevo = nuevo.length > 0 ? $filter('filter')(nuevo[0].status, 'NUEVO').length : 0;

            var espera = $filter('filter')(self.allSoportsMese, {
              mes: value,
            }, true);
            espera = espera.length > 0 ? $filter('filter')(espera[0].status, 'EN ESPERA').length : 0;

            var proceso = $filter('filter')(self.allSoportsMese, {
              mes: value,
            }, true);
            proceso = proceso.length > 0 ? $filter('filter')(proceso[0].status, 'EN PROCESO').length : 0;

            cant = nuevo + espera + proceso;
            var datas = {
              c: [
                {
                  v: value
                },
                {
                  v: (cantidad)
                },
                {
                  v: confirmado
                }, {
                  v: cant
                }
              ]
            };
            $scope.myChartObject3.data.rows.push(datas);
          });

          $scope.update = false;
        } else {
          Notification.error(res.data.msj);
        }
      }).catch(function (erro) {
        Notification.warning('¡Error! Por favor intente nuevamente!');
      });
    };


    this.loadIcon = function (status) {
      return self.icons[status];
    };

    this.getTotalForStatus = function (status) {
      return $filter('filter')(self.allSoports, {
        estado: status
      }).length;
    };

    $scope.$watch('$storage.userData', function (newValue, oldValue) {
      angular.forEach(angular.element('img.avatar'), function (value, key) {
        var elem = angular.element(value);
        elem.attr('src', elem.attr('src') + '?' + new Date());
      });
      $scope.userData = newValue;
    });

    $scope.$watch(function () {
      return self.allSoports;
    }, function (value) {
      self.allSoports = value;
      if (value !== undefined && value.length > 0)
        $scope.reload = true;
    });

    $scope.$watch('$storage.userData', function (newValue, oldValue) {
      $scope.userData = newValue;
    });

    this.regex = function (str) {
      if (str == undefined)
        str = '';
      var reg = new RegExp(".*" + $filter('slugify')(str) + ".*", "ig");
      return reg;
    };

    /**
     * filtrar entre rango de fecha de solicitud
     */
    this.requestDateRange = function (item, search) {

      if(search.dateRequest != '' && search.dateRequestEnd != '' && search.dateRequest != undefined && search.dateRequestEnd != undefined) {
        var dateStar = new Date($filter('date')(search.dateRequest, 'yyyy-MM-dd' + ' 00:00:00'));
        var dateEnd = new Date($filter('date')(search.dateRequestEnd, 'yyyy-MM-dd' + ' 00:00:00'));
        var date = new Date($filter('date')(item.fecha_solicitud, 'yyyy-MM-dd' + ' 00:00:00'));
        return date >= dateStar && date <= dateEnd;
      }else{
        return true;
      }
    };

    $scope.fnSearch = function (item) {
      var number = true;
      if ($scope.search.number !== '' && $scope.search.number !== undefined)
        number = $scope.search.number == item.number;

      if (
        self.requestDateRange(item, $scope.search) &&
        self.regex($scope.search.medium).test($filter('slugify')(item.medio)) &&
        self.regex($scope.search.imputability).test($filter('slugify')(item.imputabilidad)) &&
        self.regex($scope.search.company).test($filter('slugify')(item.company[0].nomb_comercial)) &&
        self.regex($scope.search.status).test($filter('slugify')(item.estado)) &&
        self.regex($scope.search.priority).test($filter('slugify')(item.prioridad)) &&
        self.regex($scope.search.type).test($filter('slugify')(item.tipo)) &&
        self.regex($scope.search.category).test($filter('slugify')(item.categoria)) &&
        //self.regex($scope.search.dateRequest).test($filter('date')(item.fecha_solicitud, 'yyyy-MM-dd HH:mm:ss')) &&
        self.regex($scope.search.confirm_date).test($filter('date')(item.confirm_date, 'yyyy-MM-dd HH:mm:ss')) &&
        self.regex($scope.search.assigned).test($filter('slugify')(item.assignedUser[0].name + item.assignedUser[0].lastname)) &&
        number
      ) return item;
    };

    socket.on("io-add-new-ticket", function (data) {
      if (typeof data === "object") {
        $scope.$apply(function () {
          self.allSoports.push(data);
        });
      }
    });

    //    socket.on("io-add-update-sticker", function (idem) {
    //      $scope.update = true;
    //      self.getSoports().then(function (data) {
    //        $scope.update = false;
    //      });
    //    });

}]);
