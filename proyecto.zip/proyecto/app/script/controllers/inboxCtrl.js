/***************************************************
 * Inbox
 * @package Angular
 * @subpackage - app - Script
 * @author Naycool Gonzalez <naycoolgonzalez@gmail.com>
 *         Developer web
 ****************************************************/

app.controller('inboxCtrl', [
'$localStorage',
'$scope',
'$log',
'$location',
'$timeout',
'$filter',
'Notification',
'ngProgressFactory',
'SweetAlert',
'_support',
'_users',
function (
    $localStorage,
    $scope,
    $log,
    $location,
    $timeout,
    $filter,
    Notification,
    ngProgressFactory,
    SweetAlert,
    _support,
    _users) {

    /** instancia de este controlador **/
    var self = this;

    /** Listar todos los soportes **/
    this.allSupports = [];

    /** Listar todos los usuarios **/
    this.allUsers = [];

    $scope.configGrid = {
      nticket: {
        title: "# Ticket",
        value: true
      },
      action: {
        title: "Acción",
        value: true
      },
      priority: {
        title: "Prioridad",
        value: true
      },
      by: {
        title: "Realizó",
        value: true
      },
      date: {
        title: "Fecha",
        value: true
      },
      activity:{
        title: "Actividad",
        value: true
      },
      status: {
        title: "Estado",
        value: true
      }
    };

    //Barra de progreso
    $scope.progressbar = ngProgressFactory.createInstance();
    $scope.$storage = $localStorage;

    if($scope.$storage.configGrid !== undefined && typeof $scope.$storage.configGrid[0] === "object")
      $scope.configGrid = $scope.$storage.configGrid;
    else
      $scope.$storage.configGrid = $scope.configGrid;

    /**
     * Listar todos los soportes compartidos
     * @author Desarrollador02 - Miguel Muslaco
     * @returns {object}
     */
    this.loadChangesSupports = function () {
      return _support.loadChangesSupports()
      .then(function (res) {
        if (res.data.event && res.data.data.length)
          self.allSupports = res.data.data;
        else
          Notification.error(res.data.msj);
      }).catch(function (erro) {
        Notification.warning('¡Error! Por favor intente nuevamente!');
      });
    };


    /**
     * Listar todos los usuarios del sistema
     * @author Desarrollador02 - Miguel Muslaco
     * @returns {object} [Datos del usuarios]
     */
    this.getUsuarios = function () {
      return  _users.getAllusers().then(function (res) {
        if (res.data.event && res.data.data.length)
          self.allUsuarios = res.data.data;
        else
          Notification.error(res.data.msj);
      }).catch(function (erro) {
        Notification.warning('¡Error! Por favor intente nuevamente!');
      });
    };




    /**
     * Marcar como vistas las notificaciones
     * @method markViewed
     * @return {[type]} [description]
     */
    $scope.markViewed = function (eve) {
     // angular.element(eve.currentTarget).hide();
      var marks = [];
      $checkbox = angular.element('input[name="mark"][type="checkbox"]');
      angular.forEach($checkbox, function(value, key) {
        var input = angular.element(value);
        if(input.is(':checked'))
          marks.push(input.val());
      });
    if(marks.length > 0) {

      _support.markViewed(marks)
        .then(function successCallback (res) {
          angular.element(eve.currentTarget).show();
            if(res.data.event) {
              angular.forEach($checkbox, function(value, key) {
                var input = angular.element(value);
                if(input.is(':checked')){
                  angular.element(value).parent().closest('tr').remove();
                  $scope.userData.cantInbox = $scope.userData.cantInbox -1;
                }
              });
            }
          Notification({
            message: res.data.msj,
            replaceMessage: true
          }, res.data.event ? 'success' : 'error');
        },function errorCallback (error) {
          angular.element(eve.currentTarget).show();
          console.log(error);
          Notification.warning('¡Error! al marcar la entrada como vista, por favor reintente!');
        });
      }
    };

    socket.on("io-add-new-response", function (data) {
      self.loadChangesSupports();
    });

}]);
