/***************************************************
 * Helpers
 * @package Helper
 * @author Naycool Gonzalez <naycoolgonzalez@gmail.com>
 * @description: Funciones ayudantes
 ****************************************************/

var nodemailer = require('nodemailer');
var Promise = require('promise');

var smtp = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'pordefinir@gmail.com',
    pass: 'password'
  }
});


/**
 * [Pasar a Formato url]
 * @method formatUrl
 * @param  {string} str [cadena]
 * @return {Sting}     [Cadena sin caracteres especiales]
 */
var formatUrl = (function() {
  var from = "ÃÀÁÄÂÈÉËÊÌÍÏÎÒÓÖÔÙÚÜÛãàáäâèéëêìíïîòóöôùúüûÑñÇç",
    to = "AAAAAEEEEIIIIOOOOUUUUaaaaaeeeeiiiioooouuuunncc",
    mapping = {};

  for (var i = 0, j = from.length; i < j; i++)
    mapping[from.charAt(i)] = to.charAt(i);

  return function(str) {
    var ret = [];
    for (var i = 0, j = str.length; i < j; i++) {
      var c = str.charAt(i);
      if (mapping.hasOwnProperty(str.charAt(i)))
        ret.push(mapping[c]);
      else
        ret.push(c);
    }
    return ret.join('')
      .replace(/[^-A-Za-z0-9]+/g, '-')
      .toLowerCase();
  };

})();

/**
 * Verificar datos nulos o indefindos
 * @param  {Array} array [Datos a verificar]
 * @return {bollean}
 */
var emptyDatas = function(array) {
  for (var i = 0, j = array.length; i < j; i++) {
    if (array[i] === undefined || array[i] === "" || array[i] === null)
      return false;
  }
  return true;
};

/**
 * Enviar mensaes
 * @param  {object} data [Datos del mensaje]
 * @return {[type]}      [description]
 */
var sendEmail = function(data) {
  var options = {
    from: "jenn.acobol@gmail.com",
    to: "naycoolgonzalez@gmail.com",
    subject: "Contacto web site",
    html: "El usuario: <b>" + data.name + " </b> con " + "email: " + data.email +
      " envio del siguiente mesnaje desde el sitio web : <br><br>" + data.message
  };

  return new Promise(function(resolve, reject) {
    smtp.sendMail(options, function(error, info) {
      if (error) {
        console.log(error);
        reject({
          event: false,
          data: error
        });
      } else {
        console.log('Mensaje enviado: ' + info.response);
        resolve({
          event: true,
          data: info
        });
      }
    });
  });
};

module.exports = {
  "formatUrl": formatUrl,
  "emptyDatas": emptyDatas,
  "sendEmail": sendEmail,
};
