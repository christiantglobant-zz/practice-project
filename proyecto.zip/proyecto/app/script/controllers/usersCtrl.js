/***************************************************
 * usersCtrl
 * @package JS
 * @author Naycool Gonzalez <naycoolgonzalez@gmail.com>  Developer web
 * @description: Controlador para administar usuarios principal
 *
 *****************************************************/

app.controller('usersCtrl', [
	'$localStorage',
	'$scope',
	'ngProgressFactory',
	'Notification',
	'_cropper',
	'_users',
	function (
    $localStorage,
    $scope,
    ngProgressFactory,
    Notification,
    _cropper,
    _users) {

    var self = this;

    $scope.user = angular.copy(_users.user);
    $scope.$storage = $localStorage;
    $scope.userData = $scope.$storage.userData;
    $scope.progressbar = ngProgressFactory.createInstance();
    $scope.allUsers = [];
    $scope.table = true;
    $scope.cropper = _cropper;

    this.configPhoto = angular.copy(_users.configPhoto);

    /** Configuración de mensaje de precarga **/
    $scope.configMsj = {
      delay: 0,
      minDuration: 0,
      message: 'Cargando datos...',
      backdrop: true,
      promise: null
    };
    /**
     * Activar la pestaña de buscar usuarios
     * @author Desarrollador02 - Miguel Muslaco
     */
    this.searchUser = function () {
      $scope.tab = 0;
    };
    /**
     * Cargar todos los usuarios
     * @method getAllusers
     * @return {$http}
     */
    this.getAllusers = function () {
      $scope.configMsj.promise =  _users.getAllusers()
        .then(function successCallback(res) {
          $scope.allUsers = res.data.data.length > 0 ? res.data.data : [];
          if (!res.data.event || res.data.data.length <= 0)
            Notification.error(res.data.msj);
        }, function errorCallback(error) {
          Notification.error("Se ha producido un error, Por favor intente nuevamente");
        });
    };

    /**
     * Recortar imagen
     * @method _cut
     * @param  {String} instance [Id de la imagen]
     */
    this._cut = function (instance) {
      $scope.user.image = $scope.cropper.cut(
        instance,
        self.configPhoto._sizes.cover.width,
        self.configPhoto._sizes.cover.height
      );
    };

    /**
     * Crear nuevos usuarios
     * @method newUser
     * @param  {event} eve
     */
    $scope.newUser = function (eve) {
      eve.preventDefault();
      var form = eve.target;
      if (angular.element(form).parsley().validate()) {
        $scope.save = !$scope.save;
        $scope.progressbar.start();

        _users.save($scope.user)
          .then(function successCallback(res) {
            $scope.save = !$scope.save;
            Notification({
              message: res.data.msj,
              replaceMessage: true
            }, res.data.event ? 'success' : 'error');
            $scope.progressbar.complete();
            if (res.data.event && res.data.data._id !== undefined) {
              socket.emit('io-server-new-ser', res.data.data, $scope.userData);
              angular.element(form).trigger('reset').parsley().reset();
              $scope.user = angular.copy(_users.user);
              $scope.tab = 0;
            }
          }, function errorCallback(data) {
            $scope.progressbar.complete();
            $scope.save = !$scope.save;
            Notification.error("Se ha producido un error, Por favor intente nuevamente");
          });
      } else {
        Notification.warning('Ingrese los dato del formulario y reintente');
      }
    };

    socket.on("io-add-new-user", function (data) {
      if (typeof data === "object") {
        $scope.$apply(function () {
          $scope.allUsers.push(data);
        });
      }
    });

    $scope.$watch('$storage.userData', function (newValue, oldValue) {
      $scope.userData = newValue;
    });
}]);
