/***************************************************
 * Cpanel Controller
 * @package Angular
 * @author Naycool Gonzalez <naycoolgonzalez@gmail.com>
 ****************************************************/

app.controller('cpanelCtrl', [
'$scope',
'$log',
'$location',
'$localStorage',
'$timeout',
'$filter',
'Notification',
'ngProgressFactory',
'_support',
function (
    $scope,
    $log,
    $location,
    $localStorage,
    $timeout,
    $filter,
    Notification,
    ngProgressFactory,
    _support) {

    /** instancia de este controlador **/
    var self = this;
    $scope.reload = false;
    $scope.$storage = $localStorage;
    $scope.userData = $scope.$storage.userData;

    /** Estados disponibles **/
    $scope.status = ['NUEVO', 'EN PROCESO', 'EN ESPERA', 'CERRADO', 'CONFIRMADO', 'CANCELADO'];

    /** Usuario a buscar **/
    $scope.search = {
      estado: '',
      assigned: $scope.userData.name
    };

    /** Configuración de mensaje de precarga **/
    $scope.configMsj = {
      delay: 0,
      minDuration: 0,
      message: 'Cargando datos...',
      backdrop: true,
      promise: null
    };

    $scope.update = false;

    $scope.typesCategory = angular.copy(_support.typesCategory);

    /** Iconos de detalles **/
    self.icons = {
      'all': {
        "icon": 'fa-ticket',
        "color": "rgb(255, 156, 0)"
      },
      "NUEVO": {
        "icon": 'fa-plus',
        "color": "silver"
      },
      "EN PROCESO": {
        "icon": 'fa-spinner fa-spin fa-3x fa-fw',
        "color": "rgb(51, 122, 183)"
      },
      "EN ESPERA": {
        "icon": 'fa-clock-o',
        "color": "orange"
      },
      "CERRADO": {
        "icon": 'fa-minus-square',
        "color": "black"
      },
      "CONFIRMADO": {
        "icon": 'fa-check',
        "color": "rgb(92, 184, 92)"
      },
      "CANCELADO": {
        "icon": 'fa-times',
        "color": "red"
      }
    };

    /**
     * Opciones para el carousel
     * @type {Object}
     */
    self.owlOptions = {
      loop: false,
      nav: false,
      margin: 0,
      items: 4,
      autoplay: true,
      autoplayTimeout: 5000,
      autoplayHoverPause: true,
      animateOut: 'fadeOut',
      animateIn: 'fadeIn',
    };

    $scope.filter = function (filter, value) {
      $scope.search[filter] = value;
    };

    /**
     * Listar todos los soportes del sistema
     * @author Desarrollador02 - Miguel Muslaco
     * @returns {object} [Datos del soportes]
     */
    this.getSoports = function () {
      return _support.getAllSoports().then(function (data) {
        angular.forEach(data.data.data, function (value, key) {
          var timr = self.dateDifference(value.fecha_registro);
          value.time = timr.full;
        });

        self.allSoports = data.data.data;
      }).catch(function (erro) {
        Notification.warning('¡Error! Por favor intente nuevamente!');
      });
    };

    /**
     * Diferencia de dia y fecha
     * @author Desarrollador02 - Miguel Muslaco
     * @param   {[[Type]]} dataTime [[Description]]
     * @returns {object}   [[Description]]
     */
    this.dateDifference = function (dataTime) {
      var fecha = $filter('date')(dataTime, 'yyyy-MM-dd HH:mm:ss');
      var fecha = new Date(fecha);
      var hoy = new Date();
      var days = 0;
      var hours = 0;
      var minutes = 0;
      var seconds = 0;
      var sign = '';
      var full;
      var difference;

      if (fecha > hoy) {
        var difference = (fecha.getTime() - hoy.getTime()) / 1000;
      } else {
        var difference = (hoy.getTime() - fecha.getTime()) / 1000;
      }

      days = Math.floor(difference / 86400);
      difference = difference - (86400 * days);
      hours = Math.floor(difference / 3600);
      difference = difference - (3600 * hours);
      minutes = Math.floor(difference / 60);
      difference = difference - (60 * minutes);
      seconds = Math.floor(difference);

      if (days > 0) {
        full = days;
      } else {
        full = 0;
      }
      return {
        "full": full,
      };
    };

    /** Historico desoportes **/
    this.historyCopy = [];
    /**
     * Listar todos la paginacion de soportes
     * @author Desarrollador02 - Miguel Muslaco
     * @param   {object} page
     * @returns {object}
     */
    $scope.select = function (page) {
      var end, start;
      start = (page - 1) * 10;
      end = start + 10;
      return self.historyCopy = self.history.slice(start, end);
    };


    /**
     * Listar el historial de soporte
     * @method getHistory
     * @returns {object} [Datos del soportes]
     */
    this.getHistory = function () {
      $scope.configMsj.promise = _support.getHistory().then(function (data) {
        self.history = data.data.data;
        $scope.totalReg = self.history.length / 10;
        self.historyCopy = self.history.slice(0, 10);
      }).catch(function (erro) {
        Notification.warning('¡Error! Por favor intente nuevamente!');
      });
    };

    this.loadIcon = function (status) {
      return self.icons[status];
    };

    this.getTotalForStatus = function (status) {
      return $filter('filter')(self.allSoports, {
        estado: status
      }).length;
    };

    $scope.$watch('$storage.userData', function (newValue, oldValue) {
      angular.forEach(angular.element('img.avatar'), function (value, key) {
        var elem = angular.element(value);
        elem.attr('src', elem.attr('src') + '?' + new Date());
      });
      $scope.userData = newValue;
    });

    $scope.$watch(function () {
      return self.allSoports;
    }, function (value) {
      self.allSoports = value;
      if (value !== undefined && value.length > 0)
        $scope.reload = true;
    });

    $scope.$watch('$storage.userData', function (newValue, oldValue) {
      $scope.userData = newValue;
    });

    this.regex = function (str) {
      if (str == undefined)
        str = '';
      var reg = new RegExp(".*" + $filter('slugify')(str) + ".*", "ig");
      return reg;
    };

    $scope.fnSearch = function (item) {
      var number = true;
      if ($scope.search.number !== '' && $scope.search.number !== undefined)
        number = $scope.search.number == item.number;

      if (
        self.regex($scope.search.company).test($filter('slugify')(item.company[0].nomb_comercial)) &&
        self.regex($scope.search.status).test($filter('slugify')(item.estado)) &&
        self.regex($scope.search.priority).test($filter('slugify')(item.prioridad)) &&
        self.regex($scope.search.type).test($filter('slugify')(item.tipo)) &&
        self.regex($scope.search.category).test($filter('slugify')(item.categoria)) &&
        self.regex($scope.search.assigned).test($filter('slugify')(item.assignedUser[0].name + item.assignedUser[0].lastname)) &&
        number
      ) return item;
    };

    socket.on("io-add-new-ticket", function (data) {
      if (typeof data === "object") {
        $scope.$apply(function () {
          self.allSoports.unshift(data);
        });
      }
    });

    socket.on("io-add-update-sticker", function (idem) {
      $scope.update = true;
      self.getSoports().then(function (data) {
        $scope.update = false;
      });
    });

    $scope.$watchCollection('search', function (newValue, oldValue) {
      if (newValue !== undefined && newValue !== '' && newValue !== null) {
        if (
          ($scope.search.number !== undefined && $scope.search.number !== '') ||
          ($scope.search.assigned !== undefined && $scope.search.assigned !== '') ||
          ($scope.search.company !== undefined && $scope.search.company !== '') ||
          ($scope.search.priority !== undefined && $scope.search.priority !== '') ||
          ($scope.search.type !== undefined && $scope.search.type !== '') ||
          ($scope.search.category !== undefined && $scope.search.category !== '')
        ) {
          $scope.totalReg = 1;
          self.historyCopy = self.history;
        } else {
          if (self.history) {
            self.historyCopy = self.history.slice(0, 10);
            $scope.totalReg = self.history.length / 10;
          }
        }
      }
    });
}]);
