/***************************************************
 * headerCtrl
 * @package JS
 * @author Naycool Gonzalez <naycoolgonzalez@gmail.com>  Developer web
 * @description: Controlador de la cabecera principal
 *
 *****************************************************/
app.controller('headerCtrl', [
  '$localStorage',
  '$scope',
  'packageJson',
  '_support',
  function (
    $localStorage,
    $scope,
    packageJson,
    _support) {

    var self = this;
    $scope.$storage = $localStorage;
    $scope.userData = $scope.$storage.userData;
    $scope.onLines = [];
    $scope.packageJson = packageJson.get();

    socket.on("io-message-new-user", function (data, user) {
      var user_current = $scope.userData || {};

      if(user_current._id === undefined || user_current._id !== user._id)
        Push.create("Nuevo Usuario Creado", {
          body: data.name + ' ' + data.lastname + ' Email: ' + data.email,
          icon: data.image != undefined && data.image != 'undefined' ? 'app/uploads/users/'+data.image : 'app/imagen/Vulcano-txt.png',
          timeout: 14000,
          tag: 'New-User',
          requireInteraction: true,
          onClick: function () {
            window.focus();
            this.close();
          }
        });
    });

    socket.on("io-message-new-ticket", function (data, user) {
      var user_current = $scope.userData || {};
      if(user_current._id === undefined || user_current._id !== user._id)
        Push.create("Nuevo Ticket Creado", {
          body: 'Penditen por agregar texto descriptivo',
          icon: 'app/imagen/ticket.png',
          timeout: 14000,
          requireInteraction: true,
          onClick: function () {
            window.focus();
            this.close();
          }
        });
    });

    socket.on("io-update-onlines", function (onlines) {
      $scope.$apply(function () {
        $scope.onLines = onlines;
      });
    });

    socket.on("io-advertise-login", function (onlines) {
      socket.emit('io-server-login', $scope.userData);
    });

    $scope.$watch('$storage.userData', function (newValue, oldValue) {
      angular.forEach(angular.element('img.avatar'), function(value, key) {
        var elem =angular.element(value);
        elem.attr('src', elem.attr('src') + '?' + new Date());
      });
      $scope.userData = newValue;
    });

    /**
     * mensaje de alerta a responder un ticket
     */
    socket.on("io-message-new-response", function (ticket) {
      var user_current = $scope.userData || {_id: "undefined"};
      _support.loadChangesSupports()
      .then(function (res) {
        $scope.$storage.userData.cantInbox = res.data.data.length;
      });

      if(ticket.share.indexOf(user_current._id) !== -1 || user_current._id === ticket.responsable)
        Push.create("Aviso de Respuesta", {
          body: "Se respondio soporte # " +ticket.number,
          icon: 'app/imagen/question.png',
          requireInteraction: true,
          tag: '#'+ticket.number,
          onClick: function () {
            window.focus();
            window.location = "soporte/ticket/" + ticket.number;
            this.close();
          }
        });
    });

    socket.emit('io-refrehs-onlines', true);

}]);
