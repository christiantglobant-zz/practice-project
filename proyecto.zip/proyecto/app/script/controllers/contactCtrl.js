/***************************************************
 * Manage Soporte controles
 * @package Angular
 * @subpackage - app - Script
 * @author Miguel Muslaco <mjmuslaco@gmail.com>
 *         Developer web
 ****************************************************/

app.controller('contactCtrl', [
'$scope',
'$location',
'$filter',
'Notification',
'ngProgressFactory',
'_support',
'_contact',
function (
    $scope,
    $location,
    $filter,
    Notification,
    ngProgressFactory,
    _support,
    _contact) {

    /** instancia de este controlador **/
    var self = this;

    //Barra de progreso
    $scope.progressbar = ngProgressFactory.createInstance();

    /** Variable que funciona como switch **/
    $scope.reload = false;

    /** Objeto a buscar **/
    $scope.search = {};

    /** Contacto selecionado **/
    $scope.selectContact = {};

    /** Funcion de filtro**/
    $scope.filter = function (filter, value) {
      $scope.search[filter] = value;
    };
    /** Configuración de mensaje de precarga **/
    $scope.configMsj = {
      delay: 0,
      minDuration: 0,
      message: 'Cargando datos...',
      backdrop: true,
      promise: null
    };
    /** Listar todos  los contactos **/
    this.allContact = [];

    /**
     * Activar la pestaña de buscar contacto
     * @author Desarrollador02 - Miguel Muslaco
     */
    this.searchContact = function () {
      $scope.tab = 0;
    };

    this.updateContact = function (data) {
      angular.element('#modalContactUpdate').modal('show');
      $scope.selectContact.company = data.id_cliente;
      $scope.selectContact.fullname = data.nombre;
      $scope.selectContact.email = data.correo;
      $scope.selectContact.phones = data.telefono;
      $scope.selectContact._id = data._id;
    };

    /**
     * Listar todo los clientes
     * @author Desarrollador02 - Miguel Muslaco
     * @returns {object} [Datos del clientes]
     */
    this.getAllContact = function () {
      $scope.configMsj.promise = _contact.getAllContact().then(function (data) {
        self.allContact = data.data.data.length > 0 ? data.data.data : [];
        if (!data.data.event || data.data.data.length <= 0)
          Notification.error(data.data.msj);
      }).catch(function (erro) {
        Notification.warning('¡Error! Por favor intente nuevamente!');
      });
    };

    /**
     * Filtor con contactos
     * @author Desarrollador02 - Miguel Muslaco
     * @param   {[[Type]]} str [[Description]]
     * @returns {[[Type]]} [[Description]]
     */
    this.regex = function (str) {
      if (str == undefined)
        str = '';
      var reg = new RegExp(".*" + $filter('slugify')(str) + ".*", "ig");
      return reg;
    };

    /**
     * Listar todos los clientes disponibles
     * @author Desarrollador02 - Miguel Muslaco
     * @returns {object} [Datos del clientes]
     */
    this.getClientes = function () {
      return _support.getAllClientes().then(function (data) {
        self.allClientes = data.data.data;
      }).catch(function (erro) {
        Notification.warning('¡Error! Por favor intente nuevamente!');
      });
    };
    /**
     * Se desahabilita contacto
     * @author Desarrollador02 - Miguel Muslaco
     * @param {object} contact [Datos actualizados]
     */
    $scope.disableContactsx = function (contact) {
      if (typeof contact === 'object' && contact._id !== undefined && contact._id !== 'undefined') {
      contact.estado = !contact.estado;
      $scope.progressbar.start();
      _contact.disableContact(contact)
        .then(function successCallback(res) {
          Notification({
            message: res.data.msj,
            replaceMessage: true
          },'success');
          $scope.progressbar.complete();
        }, function errorCallback(data) {
          console.log("Error", data);
          Notification.error("Se ha producido un error, Por favor intente nuevamente");
          $scope.progressbar.complete();
        });
      }else{
        Notification.warning("No se enviaron todos los datos requeridos, Por favor intente nuevamente");
      }
    };
    /**
     * Se vigila si hay cambio en el objeto de contacto
     **/
    $scope.$watch(function () {
      return self.allContact;
    }, function (value) {
      self.allContact = value;
      if (value !== undefined && value.length > 0)
        $scope.reload = true;
    });

    /**
     * Funcion para la busqueda de las palabras
     * @author Desarrollador02 - Miguel Muslaco
     * @param   {object}   item [Datos de la contacto]
     * @returns {object}
     */
    $scope.fnSearch = function (item) {
      var number = 3;
      if ($scope.search.status !== '' && $scope.search.status !== undefined)
        if ($scope.search.status == "true") {
          number = true;
          number = (number == item.estado);
        } else if ($scope.search.status == "false") {
        number = false;
        number = (number == item.estado);
      }
      if (self.regex($scope.search.company).test($filter('slugify')(item.company[0].nomb_comercial)) &&
        self.regex($scope.search.nombres).test($filter('slugify')(item.nombre)) && number ) return item;
    };

    /**
     * Crear un nuevo contacto
     * @author Desarrollador02 - Miguel Muslaco
     * @param {object} event [Datos del contacto]
     */
    $scope.newConctComp = function (event) {
      event.preventDefault();
      var form = event.target;
      if (angular.element(form).parsley().validate()) {
        _contact.newConctComp($scope.conct)
          .then(function successCallback(data) {
            if (data.data.event && data.data.data._id !== undefined) {
              angular.element(form).trigger('reset').parsley().reset();
              angular.element('#modalContact').modal('hide');
              self.allContact.push(data.data.data);
            }
            Notification({
              message: data.data.msj,
              replaceMessage: true
            }, data.data.event ? 'success' : 'error');
          }, function errorCallback(data) {
            console.log("Error", data);
          });
      } else {
        Notification.warning('Verifique los datos requeridos!!! por favor intente de nuevo');
      }
    };
    /**
     * Actualizar el contacto
     * @author Desarrollador02 - Miguel Muslaco
     * @param {object} eve
     */
    $scope.updateContact = function (eve) {
      eve.preventDefault();
      var form = eve.target;
      if (angular.element(form).parsley().validate()) {
        $scope.progressbar.start();
        $scope.save = !$scope.save;
        _contact.updateContact($scope.selectContact)
          .then(function successCallback(res) {
            Notification({
              message: res.data.msj,
              replaceMessage: true
            }, res.data.event ? 'success' : 'error');
            $scope.progressbar.complete();
            $scope.save = !$scope.save;
            self.getAllContact();
            angular.element('#modalContactUpdate').modal('hide');
          }, function errorCallback(data) {
            $scope.progressbar.complete();
            $scope.save = !$scope.save;
            Notification.error("Se ha producido un error, Por favor intente nuevamente");
          });
      } else {
        Notification.warning('Ingrese los dato del formulario y reintente');
      }
    };


}]);