/***************************************************
 * Services
 * @package Angular
 * @subpackage Js
 * @author Miguel Muslaco <mjmuslaco@gmail.com>
 *         Developer web
 *
 * Description: servicios
 ****************************************************/

/**
 * Funcion para logiarte
 * el usuario inicial
 **/
app.service('_login', ['$http', function ($http) {

  var login = function (user) {
    return $http({
      method: 'POST',
      url: 'server/login',
      headers: {
        'Content-Type': undefined
      },
      params: user
    });
  };

  /**
   * Verficar sesion activa
   * @method verifySession
   * @param  {string} user [email o username]
   * @return {$http}
   */
  var verifySession = function (user) {
    return $http({
      method: 'POST',
      url: 'server/verifySession',
      headers: {
        'Content-Type': undefined
      },
      params: {
        username: user
      }
    });
  };

  /**
   *Terminar la seccion del usuario
   * @author Desarrollador02 - Miguel Muslaco
   * @returns {object}
   */
  var logout = function () {
    return $http({
      method: 'POST',
      url: 'server/logout',
      headers: {
        'Content-Type': undefined
      },
    });
  };

  /**
   * [Listado de funciones disponibles]
   * @type {Object}
   */
  return {
    "login": login,
    "logout": logout,
    "verifySession": verifySession
  };

}]);


/**
 * Funcion para guardar
 * el soporte inicial
 **/
app.service('_support', ['$http', function ($http) {

  /** Objeto soporte **/
  var support = {
    company: "",
    mainContact: "",
    telContact: "",
    emailContact: "",
    //Datos Básicos
    typeSupport: "",
    medium: "",
    category: "",
    responsible: "",
    imputability: "",
    dateRequest: "",
    priority: "",
    status: "",
    affair: "",
    description: "",
    attachments: [],
  };

  /** Objeto de respuesta del soporte **/
  var supportDetalls = {
    sticker: "",
    username: "",
    response: "",
    status: ""
  };

  /**
   * Extenciones permitidas para adjuntar archivos en soportes
   * @type {Array}
   */
  var attachmentsExt = [
    "doc", "docx", "docm", "dotx", "dotm", "odt",
    "xls", "xlsx", "xlsm", "xltx", "xltm", "xlsb", "xlam", "ods",
    "jpg", "png", "jpeg",
    "pdf",
    "mp4", "wmv"
  ];

  var typesCategory = [
    {
      id: 'C1',
      name: 'RNDC'
      },
    {
      id: 'C2',
      name: 'Error Contable'
      },
    {
      id: 'C3',
      name: 'Error General'
      },
    {
      id: 'C4',
      name: 'Solicitudes'
      }, {
      id: 'G1',
      name: 'Radicacion Ministerio - RNDC'
      },
    {
      id: 'G2',
      name: 'Errores Comerciales'
      },
    {
      id: 'G3',
      name: 'Errores Operativos'
      },
    {
      id: 'G4',
      name: 'Errores Administrativos'
      },
    {
      id: 'G5',
      name: 'Errores Contables'
      },
    {
      id: 'G6',
      name: 'Quejas por Servicio'
      },
    {
      id: 'G7',
      name: 'Consultas'
      },
    {
      id: 'I1',
      name: 'Indicadores'
      },
    {
      id: 'N1',
      name: 'Nomina'
      },
    {
      id: 'V1',
      name: 'Veycom'
      }, {
      id: 'IM',
      name: 'Implementación'
      }

    ];
  /**
   * Listar todos los soportes
   * @author Desarrollador02 - Miguel Muslaco
   * @param   {object} data [Datos del soportes]
   * @returns {object}
   */
  var getAllSoports = function (data) {
    return $http({
      method: 'POST',
      url: 'server/allSupport',
      headers: {
        'Content-Type': undefined
      },
    });
  };
  /**
   * Listar todos los contactos de una empresa
   * @author Desarrollador02 - Miguel Muslaco
   * @param   {[[Type]]} data [[Description]]
   * @returns {[[Type]]} [[Description]]
   */
  var getContactComp = function (data) {
    return $http({
      method: 'POST',
      url: 'server/getContactComp',
      headers: {
        'Content-Type': undefined
      },
      params: {
        id: data
      }
    });
  };

  /**
   * Listar la informacion del sticker
   * @author Desarrollador02 - Miguel Muslaco
   * @param   {object} data [Numero del sticker]
   * @returns {object}
   */
  var getInfoTickets = function (data) {
    return $http({
      method: 'POST',
      url: 'server/infoTickets',
      headers: {
        'Content-Type': undefined
      },
      params: {
        sticker: data
      }
    });
  };
  /**
   * Informacion del ticket para editar
   * @author Desarrollador02 - Miguel Muslaco
   * @param   {object} data [Datos tickert]
   * @returns {object}
   */
  var infoTicketsEdits = function (data) {
    return $http({
      method: 'POST',
      url: 'server/infoTicketsEdits',
      headers: {
        'Content-Type': undefined
      },
      params: {
        idem: data
      }
    });
  };
  /**
   * Listar todos los responsables
   * @author Desarrollador02 - Miguel Muslaco
   * @param   {[[Type]]} data [[Description]]
   * @returns {[[Type]]} [[Description]]
   */
  var getresponse = function (data) {
    return $http({
      method: 'POST',
      url: 'server/getresponse',
      headers: {
        'Content-Type': undefined
      },
      params: {
        sticker: data
      }
    });
  };

  /**
   * Listar la informacion
   * @author Desarrollador02 - Miguel Muslaco
   * @param   {[[Type]]} data [[Description]]
   * @returns {[[Type]]} [[Description]]
   */
  var getAllUsuarios = function (data) {
    return $http({
      method: 'POST',
      url: 'server/allUsuarios',
      headers: {
        'Content-Type': undefined
      },
      params: data
    });
  };

  /**
   * Listart todos los clientes
   * @author Desarrollador02 - Miguel Muslaco
   * @param   {[[Type]]} data [[Description]]
   * @returns {[[Type]]} [[Description]]
   */
  var getAllClientes = function (data) {
    return $http({
      method: 'POST',
      url: 'server/allClientes',
      headers: {
        'Content-Type': undefined
      },
      params: data
    });
  };

  /**
   * Crear un soportes
   * @author Desarrollador02 - Miguel Muslaco
   * @param   {object} data [Datos del soporte]
   * @returns {object}
   */
  var insertSupport = function (data) {
    return $http({
      method: 'POST',
      url: 'server/saveSupport',
      headers: {
        'Content-Type': 'application/json'
      },
      data: data
    });
  };

  /**
   * Crear respuestas de soportes
   * @author Desarrollador02 - Miguel Muslaco
   * @param   {object} data [Datos del soportes de respuestas]
   * @returns {object}
   */
  var newSupportDetalls = function (data) {
    return $http({
      method: 'POST',
      url: 'server/newSupportDetalls',
      headers: {
        'Content-Type': 'application/json'
      },
      data: data
    });
  };
  /**
   * Nuevos contactos para las empresas
   * @author Desarrollador02 - Miguel Muslaco
   * @param   {[[Type]]} data [[Description]]
   * @returns {[[Type]]} [[Description]]
   */
  var newConct = function (data) {
    return $http({
      method: 'POST',
      url: 'server/newConct',
      headers: {
        'Content-Type': undefined
      },
      params: data
    });
  };

  /**
   * Cambiar estado de un tickect
   * @method changeStatusTicket
   * @param  {[type]} data [description]
   * @return {[type]}      [description]
   */
  var changeStatusTicket = function (ticket, status) {
    return $http({
      method: 'POST',
      url: 'server/changeStatusTicket',
      headers: {
        'Content-Type': undefined
      },
      params: {
        ticket: ticket,
        status: status
      }
    });
  };

  /**
   * Selecionar los usuarios de stike
   * @author Desarrollador02 - Miguel Muslaco
   * @param   {number} ticket [Numero del ticker]
   * @param   {number} user   [ID de usuario]
   * @returns {object}
   */
  var changeUserTicket = function (ticket, user, response) {
    return $http({
      method: 'POST',
      url: 'server/changeUserTicket',
      headers: {
        'Content-Type': undefined
      },
      params: {
        ticket: ticket,
        user: user,
        response: response
      }
    });
  };

  /**
   * Listar el historial
   * @returns {object}
   */
  var getHistory = function () {
    return $http({
      method: 'POST',
      url: 'server/getHistory',
      headers: {
        'Content-Type': undefined
      },
    });
  };

  /**
   * Actualizar la información del soporte
   * @author Desarrollador02 - Miguel Muslaco
   * @param   {object} user [[Description]]
   * @returns {object}
   */
  var updateSupport = function (user) {
    return $http({
      method: 'POST',
      url: 'server/updateSupport',
      headers: {
        'Content-Type': 'application/json'
      },
      data: user,
    });
  };


  var getTotalSuportsResult = function (init, finis) {
    return $http({
      method: 'POST',
      url: 'server/getTotalSuportsResult',
      headers: {
        'Content-Type': undefined
      },
      params: {
        init: init,
        finis: finis,
      }
    });
  };
  /**
   * Listar todos los soportes que existen
   * @method getTotalSuports
   * @return {$http}
   */
  var getTotalSuports = function () {
    return $http({
      method: 'POST',
      url: 'server/getTotalSuports',
      headers: {
        'Content-Type': undefined
      },
    });
  };

  var getTotalSuportsMeses = function () {
    return $http({
      method: 'POST',
      url: 'server/getTotalSuportsMeses',
      headers: {
        'Content-Type': undefined
      },
    });
  };

  /**
   * Actualizar usuarios compartidos del ticket
   * @method updateShareTicket
   * @param  {Object} ticket [Datos del ticket]
   * @return {$http}
   */
  var updateShareTicket = function (ticket) {
    return $http({
      method: 'POST',
      url: 'server/updateShareTicket',
      headers: {
        'Content-Type': 'application/json'
      },
      data: {
        _id: ticket._id,
        number: ticket.number,
        share: ticket.share
      }
    });
  };
  /**
   * Listar todos los soportes
   * @author Desarrollador02 - Miguel Muslaco
   * @returns {object}
   */
  var loadChangesSupports = function () {
    return $http({
      method: 'POST',
      url: 'server/loadChangesSupports',
      headers: {
        'Content-Type': undefined
      },
    });
  };


  var changePriority = function (ticket, priority, response) {
    return $http({
      method: 'POST',
      url: 'server/changePriority',
      headers: {
        'Content-Type': undefined
      },
      params: {
        ticket: ticket,
        priority: priority,
        response: response
      }
    });
  };
  /**
   * Marcar seguimientos como vistos
   * @method markViewed
   * @param  {Array} inbox [id de las entradas]
   * @return {[type]}         [description]
   */
  var markViewed = function (inbox) {
    return $http({
      method: 'POST',
      url: 'server/markViewed',
      headers: {
        'Content-Type': 'application/json'
      },
      data: {
        inbox: inbox
      },
    });
  };

  /**
   * [Listado de funciones disponibles]
   * @type {Object}
   */
  return {
    "attachmentsExt": attachmentsExt,
    "support": support,
    "insertSupport": insertSupport,
    "getAllSoports": getAllSoports,
    "getAllUsuarios": getAllUsuarios,
    "getInfoTickets": getInfoTickets,
    "getAllClientes": getAllClientes,
    "supportDetalls": supportDetalls,
    "newSupportDetalls": newSupportDetalls,
    "getresponse": getresponse,
    "getContactComp": getContactComp,
    "newConct": newConct,
    "changeStatusTicket": changeStatusTicket,
    "getHistory": getHistory,
    "infoTicketsEdits": infoTicketsEdits,
    "updateSupport": updateSupport,
    "getTotalSuports": getTotalSuports,
    "getTotalSuportsResult": getTotalSuportsResult,
    "updateShareTicket": updateShareTicket,
    "loadChangesSupports": loadChangesSupports,
    "changeUserTicket": changeUserTicket,
    "markViewed": markViewed,
    "changePriority": changePriority,
    "getTotalSuportsMeses": getTotalSuportsMeses,
    "typesCategory": typesCategory,
  };

}]);

app.service('_users', ['$http', function ($http) {

  /**
   * Configuración del recorte del avatar
   * @type {Object}
   */
  var configPhoto = {
    aspectRatio: 1 / 1,
    background: true,
    checkCrossOrigin: true,
    responsive: true,
    autoCropArea: 1,
    _sizes: { //Tamaños de los cortes de las imagenes
      cover: {
        width: 300,
        height: 300,
      },
      thumbnail: {
        width: 150,
        height: 150,
      }
    }
  };


  //Datos de un usuario
  var user = {
    name: "",
    lastname: "",
    tel: "",
    email: "",
    password: "",
    password2: "",
    image: undefined,
    username: ""
  };

  /**
   * Guardar datos de un usuario
   * @method save
   * @param  {object} user [Datos del usario]
   * @return {$http}
   */
  var save = function (user) {
    return $http({
      method: 'POST',
      url: 'server/newUser',
      headers: {
        'Content-Type': 'application/json'
      },
      data: user,
    });
  };

  /**
   * actualizar datos de un usuario
   * @method update
   * @param  {object} user [Datos del usario]
   * @return {$http}
   */
  var update = function (user) {
    return $http({
      method: 'POST',
      url: 'server/updateUser',
      headers: {
        'Content-Type': 'application/json'
      },
      data: user,
    });
  };

  /**
   * Cambiar password
   * @method changePassword
   * @param  {String} password [Nueva contraseña]
   * @return {$http}
   */
  var changePassword = function (password) {
    return $http({
      method: 'POST',
      url: 'server/changePassword',
      headers: {
        'Content-Type': 'application/json'
      },
      data: {
        password: password
      },
    });
  };

  /**
   * Cargar todos los usuarios del sistema
   * @method getAllusers
   * @return {$http}
   */
  var getAllusers = function (limit) {
    return $http({
      method: 'POST',
      url: 'server/getUsers',
      headers: {
        'Content-Type': undefined
      }
    });
  };

  /**
   * [Listado de funciones disponibles]
   * @type {Object}
   */
  return {
    "changePassword": changePassword,
    "configPhoto": configPhoto,
    "getAllusers": getAllusers,
    "save": save,
    "user": user,
    "update": update,
  };

}]);

app.service('_client', ['$http', function ($http) {

  /**
   * Configuración del recorte del avatar
   * @type {Object}
   */
  var configPhoto = {
    aspectRatio: 1 / 1,
    background: true,
    checkCrossOrigin: true,
    responsive: true,
    autoCropArea: 1,
    _sizes: { //Tamaños de los cortes de las imagenes
      cover: {
        width: 500,
        height: 250,
      },
      thumbnail: {
        width: 300,
        height: 150,
      }
    }
  };

  /** Datos de un usuario **/
  var client = {
    nit: "",
    cod: "",
    business_name: "",
    tradename: "",
    mail: "",
    phone: "",
    image: undefined,
  };

  /**
   * Listar todos los clientes
   * @author Desarrollador02 - Miguel Muslaco
   * @param   {object} data [Listado de cliente con datos]
   * @returns {object}
   */
  var getAllClients = function (data) {
    return $http({
      method: 'POST',
      url: 'server/allClients',
      headers: {
        'Content-Type': undefined
      },
      params: data
    });
  };

  /**
   * Crear un nuevo cliente
   * @author Desarrollador02 - Miguel Muslaco
   * @param   {object} data [[Description]]
   * @returns {[[Type]]} [[Description]]
   */
  var newClient = function (data) {
    return $http({
      method: 'POST',
      url: 'server/newClient',
      headers: {
        'Content-Type': 'application/json'
      },
      data: data,
    });
  };
  /**
   * Listar la informacion del clientes para editar
   * @author Desarrollador02 - Miguel Muslaco
   * @param   {object} data [Datos del cliente]
   * @returns {object}
   */
  var getInfoClient = function (data) {
    return $http({
      method: 'POST',
      url: 'server/getInfoClient',
      headers: {
        'Content-Type': undefined
      },
      params: {
        idem: data
      }
    });
  };

  /**
   * Actuazlizar la informacion del cliente
   * @author Desarrollador02 - Miguel Muslaco
   * @param   {object} user [Datos del cliente]
   * @returns {object}
   */
  var updateClient = function (user) {
    return $http({
      method: 'POST',
      url: 'server/updateClient',
      headers: {
        'Content-Type': 'application/json'
      },
      data: user,
    });
  };

  var disableClient = function (user) {
    return $http({
      method: 'POST',
      url: 'server/disableClient',
      headers: {
        'Content-Type': 'application/json'
      },
      data: user,
    });
  };

  /**
   * [Listado de funciones disponibles]
   * @type {Object}
   */
  return {
    "client": client,
    "newClient": newClient,
    "configPhoto": configPhoto,
    "getAllClients": getAllClients,
    "getInfoClient": getInfoClient,
    "updateClient": updateClient,
    "disableClient": disableClient,
  };

}]);

app.service('_contact', ['$http', function ($http) {
  /**
   * Listar todos los clientes
   * @author Desarrollador02 - Miguel Muslaco
   * @param   {object} data [Listado de cliente con datos]
   * @returns {object}
   */
  var getAllContact = function () {
    return $http({
      method: 'POST',
      url: 'server/getAllContact',
      headers: {
        'Content-Type': undefined
      },
    });
  };

  /**
   * Nuevo contacto
   * @author Desarrollador02 - Miguel Muslaco
   * @param   {object} data [Datos del contacto]
   * @returns {object}
   */
  var newConctComp = function (data) {
    return $http({
      method: 'POST',
      url: 'server/newConctComp',
      headers: {
        'Content-Type': undefined
      },
      params: data
    });
  };


  var updateContact = function (data) {
    return $http({
      method: 'POST',
      url: 'server/updateContact',
      headers: {
        'Content-Type': 'application/json'
      },
      data: data,
    });
  };

  var disableContact = function (user) {
    return $http({
      method: 'POST',
      url: 'server/disableContact',
      headers: {
        'Content-Type': 'application/json'
      },
      data: user,
    });
  };
  /**
   * [Listado de funciones disponibles]
   * @type {Object}
   */
  return {
    "getAllContact": getAllContact,
    "newConctComp": newConctComp,
    "updateContact": updateContact,
    "disableContact": disableContact,
  };

}]);

/**
 * Servicio para realizar recortes de imagenes
 */
app.service('_cropper', ['Notification', function (Notification) {

  var that = this;

  /**
   * Imagenes instanciadas
   * @type {Array}
   */
  this.image = [];

  /**
   * [creo un object url administrar la url de la imagen a importar]
   * @type {object}
   */
  this.URL = window.URL || window.webkitURL;
  /**
   * url de la imagen a importar
   */
  this.blobURL = null;

  /**
   * Opciones del recorte
   * @type {Object}
   */
  this.options = {
    /**
     * Opciones por defecto
     * @type {Object}
     */
    default: {
      aspectRatio: NaN,
      background: false,
      checkCrossOrigin: true,
      responsive: false,
    },
    /**
     * Opciones para cada instacia de recorte
     * @type {Array}
     */
    custom: [],
  };

  /**
   * Se vigila el input de la instacia de recorte
   * @method inputCustom
   * @param  {String} input [Id del input]
   * @param  {String} img   [Id de la imagen]
   */
  var inputCustom = function (input, img) {
    var self = this,
      index = that.image.indexOf(img);
    input = $(input);

    input.change(function () {
      var files = this.files;
      var file;

      if (!$(that.image[index])
        .data('cropper')) {
        return;
      }

      if (files && files.length) {
        file = files[0];
        if (/^image\/\w+$/.test(file.type)) {
          that.blobURL = that.URL.createObjectURL(file);
          $(that.image[index])
            .one('built.cropper', function () {
              // Revoke when load complete
              that.URL.revokeObjectURL(that.blobURL);
            })
            .cropper('reset')
            .cropper('replace', that.blobURL);
          $(that.image[index])
            .cropper()[0].crossOrigin = true;
          input.val('');
        } else {
          Notification.error('Formato no permitido');
        }
      }
    });
  };

  /**
   * Restablecer el canvar del recorte
   * @method reset
   * @param  {String} image   [Id de la imagen]
   */
  var reset = function (image) {
    var i = that.image.indexOf(image);
    $(that.image[i])
      .cropper('destroy');
    $(that.image[i])
      .cropper(that.options.custom[i]);
    $(that.image[i])[0].crossOrigin = null;
  };

  /**
   * Recortar imagen
   * @method cut
   * @param  {String} image   [Id de la imagen]
   * @param  {Integer} width  [Ancho del corte]
   * @param  {Integer} height [Alto del corte]
   * @return {Base64}        [imagen en base64]
   */
  var cut = function (image, width, height) {
    var i = that.image.indexOf(image),
      canvas = null,
      dataURL = null;

    if ($(that.image[i])[0].crossOrigin !== null) {
      canvas = $(that.image[i])
        .cropper('getCroppedCanvas', {
          width: width,
          height: height,
          fillColor: 'white',
        });
      dataURL = canvas.toDataURL('image/jpeg', 60 / 100);
    } else {
      Notification.error('Debe importar una imagen');
    }
    return dataURL;
  };

  /**
   * [load Funcion para cargar el plugin]
   * @param  [String] image   [Id de la imagen]
   * @param  [Object] options [Opciones para el plugin]
   * @param  [String] input   [Id del input file]
   */
  var load = function (image, options, input) {
    options = (options !== false && options !== '' && options !== undefined) ? options : that.options.default;
    that.options.custom.push(options);
    that.image.push(image);
    inputCustom(input, image);
    var i = that.image.indexOf(image);
    $(that.image[i])
      .cropper(that.options.custom[i]); //Inicializo cropper
  };

  /**
   * Funciones del servicio
   * @type {Object}
   */
  return {
    "cut": cut,
    "load": load,
    "reset": reset,
  };

  }]);
