/***************************************************
 * Manage Soporte controles
 * @package Angular
 * @subpackage - app - Script
 * @author Miguel Muslaco <mjmuslaco@gmail.com>
 *         Developer web
 ****************************************************/

app.controller('supportCtrl', [
'$localStorage',
'$scope',
'$log',
'$location',
'$timeout',
'$filter',
'Notification',
'ngProgressFactory',
'SweetAlert',
'_support',
'_users',
function (
    $localStorage,
    $scope,
    $log,
    $location,
    $timeout,
    $filter,
    Notification,
    ngProgressFactory,
    SweetAlert,
    _support,
    _users) {

    /** instancia de este controlador **/
    var self = this;

    this.verif = "ABIERTO";

    /** Datos de localstore **/
    $scope.userData = $scope.$storage.userData;

    /** Accion del boton **/
    $scope.actiselecBTN = false;

    /** Activar boton de redirecionar **/
    $scope.activebtnRec = true;

    /** Activar tab de busqueda **/
    $scope.tab = 0;

    /** Barra de progreso **/
    $scope.progressbar = ngProgressFactory.createInstance();

    /** Copia del objeto del stiker **/
    $scope.support = angular.copy(_support.support);

    /** Obtener todos las extenciones validas **/
    $scope.attachmentsExt = angular.copy(_support.attachmentsExt);

    /** Copia del objeto del stiker para responder **/
    $scope.supportDetalls = angular.copy(_support.supportDetalls);

    $scope.typesCategory = angular.copy(_support.typesCategory);

    /** Estados disponibles **/
    $scope.status = [
      {
        "name": "NUEVO",
        "icon": 'fa-plus',
        "color": "silver",
      },
      {
        "name": "EN PROCESO",

        "icon": 'fa-spinner',
        "color": "rgb(51, 122, 183)"
      },
      {
        "name": "EN ESPERA",

        "icon": 'fa-clock-o',
        "color": "orange"
      },
      {
        "name": "CERRADO",

        "icon": 'fa-minus-square',
        "color": "black"
      },
      {
        "name": "CANCELADO",
        "icon": 'fa-times',
        "color": "red"
      }
    ];

    /** Variable de comprobar **/
    $scope.reload = false;

    /** Variable de busqueda **/
    $scope.search = {
      estado: '',
      assigned: ''
    };

    /** Configuración de mensaje de precarga **/
    $scope.configMsj = {
      delay: 0,
      minDuration: 0,
      message: 'Cargando datos...',
      backdrop: true,
      promise: null
    };

    /** configuracion de editor **/
    $scope.mediumEditor = {
      'targetBlank': true,
      'toolbar': {
        'buttons': [
          'bold',
          'italic',
          'underline',
          'anchor',
          'unorderedlist',
          'h4',
          'h5',
          'unorderedlist',
          'orderedlist',
          'justifyFull'
        ]
      }
    };

    /** Variable que contiene los filtros **/
    $scope.filter = function (filter, value) {
      $scope.search[filter] = value;
    };
    /** Validar el estado del ticket**/
    $scope.validateStatus = function (status) {
      if (self.tickersInfo.length > 0) {
        return status === 'NUEVO' || (status === 'CANCELADO' && $scope.userData._id != self.tickersInfo.assigned_user[0]._id);
      }
    };

    /** Configuración del select2 para usuario **/
    $scope.select2Options = {
      templateResult: function (user) {
        var img = user.title !== 'undefined' && user.title !== undefined ? "app/uploads/users/" + user.id + ".jpg" : 'app/imagen/usuarios.png';
        if (!user.id) {
          return user.text;
        }
        var $state = $('<span>' + '<img src="' + img + '" class="img-flag" /><i class="txtSlect">' + user.text + '</i></span>');
        return $state;
      }
    };

    /** Activar la pestaña de crear soporte **/
    $scope.tab = $location.$$hash === 'Newsupport' ? 1 : 0;

    /** Listar todos los soportes **/
    this.allSoports = [];

    /** Listar todos los usuarios **/
    this.allUsuarios = [];

    /** Listar todos los clientes **/
    this.allClientes = [];

    /** Listar la informacion del sticker **/
    this.tickersInfo = [];

    this.infoTicketsEdits = [];

    /** Listar todos los contacto de una empresa**/
    this.contactComp = [];

    /** Obtener el numero sticker de la URL **/
    var sticker = $location.path().split("/")[3];

    /**
     * Remover archivo de los adjuntis
     * @method removeAttachments
     * @param  {number} index [posicion del archivo]
     */
    this.removeAttachments = function (index) {
      $scope.support.attachments.splice(index, 1);
    };

    /**
     * Activar la pestaña de buscar soporte
     * @author Desarrollador02 - Miguel Muslaco
     */
    this.searchSupport = function () {
      $scope.tab = 0;
    };

    /**
     * Listar todos los soportes del sistema
     * @author Desarrollador02 - Miguel Muslaco
     * @returns {object} [Datos del soportes]
     */
    this.getSoports = function () {
      $scope.configMsj.promise = _support.getAllSoports().then(function (res) {
        if (res.data.event && res.data.data.length) {
          self.allSoports = res.data.data;
        } else {
          Notification.error(res.data.msj);
        }
      }).catch(function (erro) {
        Notification.warning('¡Error! Por favor intente nuevamente!');
      });
    };

    /**
     * Listar todos los usuarios del sistema
     * @author Desarrollador02 - Miguel Muslaco
     * @returns {object} [Datos del usuarios]
     */
    this.getUsuarios = function () {
      return _users.getAllusers().then(function (res) {
        if (res.data.event && res.data.data.length) {
          self.allUsuarios = res.data.data;
        } else {
          Notification.error(res.data.msj);
        }
      }).catch(function (erro) {
        Notification.warning('¡Error! Por favor intente nuevamente!');
      });
    };

    /**
     * Listar todos los clientes disponibles
     * @author Desarrollador02 - Miguel Muslaco
     * @returns {object} [Datos del clientes]
     */
    this.getClientes = function () {
      return _support.getAllClientes().then(function (data) {
        self.allClientes = data.data.data;
      }).catch(function (erro) {
        Notification.warning('¡Error! Por favor intente nuevamente!');
      });
    };

    /**
     * Listar información del soporte
     * @author Desarrollador02 - Miguel Muslaco
     * @returns {object}
     */
    this.infoTicketsEdits = function () {
      if (parseInt(sticker)) {
        return _support.infoTicketsEdits(sticker).then(function (get) {
          self.tickersInfo = get.data.data;
          $scope.support.company = self.tickersInfo.id_cliente;
          $scope.support.typeSupport = self.tickersInfo.tipo;
          $scope.support.medium = self.tickersInfo.medio;
          $scope.support.category = self.tickersInfo.categoria;
          $scope.support.responsible = self.tickersInfo.responsable;
          $scope.support.imputability = self.tickersInfo.imputabilidad;
          $scope.support.priority = self.tickersInfo.prioridad;
          $scope.support.affair = self.tickersInfo.asunto;
          $scope.support.description = self.tickersInfo.descripcion;
          $scope.support.mainContact = self.tickersInfo.id_contacto;
        }).catch(function (erro) {
          Notification.warning('¡Error! Por favor intente nuevamente!');
        });
      }
    };

    /**
     * Descripcion del soporte a buscar
     * @author Desarrollador02 - Miguel Muslaco
     * @returns {object} [Datos del soporte]
     */
    this.infoTickets = function () {
      if (parseInt(sticker)) {
        return _support.getInfoTickets(sticker)
          .then(function (get) {
            get.data.data[0].share = Array.isArray(get.data.data[0].share) ? get.data.data[0].share : [];
            var data = get.data.data[0],
              solicitante = data.applicant[0],
              detailDdate = self.dateDifference(data.fecha_registro);
            ((data.estado == 'CERRADO') && (self.verif = "CERRADO"));

            $scope.supportDetalls.status = data.estado;
            data.date_inf = detailDdate.full;
            data.vence = detailDdate.expires;
            data.infoDate = detailDdate.infoDate;
            data.dayPlub = detailDdate.dayPlub;
            data.applicant = solicitante;
            data.infoDateVence = detailDdate.infoDateVence;
            self.tickersInfo = data;
            _support.getresponse(self.tickersInfo._id).then(function (datas) {
              angular.forEach(datas.data.data, function (value, key) {
                var username = value.assigned_users[0];
                var timr = self.dateDifference(value.fecha_registro);
                value.time = timr.full;
                value.infoDate = timr.infoDate;
              });
              data.respuestas = datas.data.data;
            }).catch(function (erro) {
              console.log(erro);
              Notification.error('¡Se ha presentado un error!');
            });

          }).catch(function (erro) {
            Notification.warning('¡Error! Por favor intente nuevamente!');
          });
      }
    };

    /**
     * Obtengo la diferencias entre dos fechas
     * @author Desarrollador02 - Miguel Muslaco
     * @param   {string} dataTime [Fecha de la solicitud]
     * @returns {object}
     */
    this.dateDifference = function (dataTime) {
      var fecha = $filter('date')(dataTime, 'yyyy-MM-dd HH:mm:ss');
      var month = $filter('date')(dataTime, 'MMM'),
        fecha = new Date(fecha),
        hoy = new Date(),
        days = 0,
        hours = 0,
        minutes = 0,
        seconds = 0,
        full,
        expires,
        difference = (fecha > hoy) ? (fecha.getTime() - hoy.getTime()) / 1000 : (hoy.getTime() - fecha.getTime()) / 1000,
        infoDateVence;

      days = Math.floor(difference / 86400);
      difference = difference - (86400 * days);
      hours = Math.floor(difference / 3600);
      difference = difference - (3600 * hours);
      minutes = Math.floor(difference / 60);
      difference = difference - (60 * minutes);
      seconds = Math.floor(difference);

      if (days > 0) {
        full = days + ' dias ';
      } else if (hours > 0) {
        full = hours + ' hora ';
      } else {
        full = minutes == 0 ? ' unos segundos' : (minutes + ' min ');
      }

      if (((fecha.getDate() + 2) == hoy.getDate()) &&
        (fecha.getMonth() == hoy.getMonth()) &&
        (fecha.getFullYear() == hoy.getFullYear()) &&
        (fecha.getHours() == hoy.getHours()) &&
        (fecha.getMinutes() == hoy.getMinutes())) {
        expires = "El tiempo limite de respuesta se ha vencido";
      } else if (fecha.getMonth() == hoy.getMonth()) {
        if (((fecha.getDate() + 2) - hoy.getDate()) === 0) {
          expires = "Se vence en el dia de hoy";
        } else {
          expires = "Vence en " + ((fecha.getDate() + 2) - hoy.getDate()) + " dias ";
        }
      }
      var lastDay = fecha.getUTCDay();
      var dias = ["Domingo", "Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado"],
        horaFina = $filter('date')(new Date(dataTime), 'h:mm:s a'),
        infoDate = dias[lastDay] + ", " + (fecha.getDate()) + " " + month + " " + horaFina,
        dayPlub = dias[fecha.getUTCDay()];
      if (lastDay >= 5) {
        infoDateVence = dias[2] + ", " + (fecha.getDate() + 4) + " " + month + " " + horaFina;
      } else {
        infoDateVence = dias[lastDay + 2] + ", " + (fecha.getDate() + 2) + " " + month + " " + horaFina;
      }

      return {
        "full": full,
        "expires": expires,
        "infoDate": infoDate,
        "infoDateVence": infoDateVence,
        "dayPlub": dayPlub,
      };
    };

    /**
     * Crear un nuevo soporte
     * @author Desarrollador02 - Miguel Muslaco
     * @param {object} event [Datoas del evento]
     */
    $scope.newSupport = function (event) {
      event.preventDefault();
      var form = event.target;
      if (angular.element(form).parsley().validate()) {
        $scope.progressbar.start();
        $scope.save = !$scope.save;
        var dateFinal = $filter('date')($scope.support.dateRequest, 'yyyy-MM-dd' + " " + ($filter('date')(new Date(Date.now()), 'HH:mm:ss')));
        $scope.support.dateRequest = dateFinal;
        _support.insertSupport($scope.support)
          .then(function successCallback(res) {
            if (res.data.event && res.data.data._id !== undefined) {
              socket.emit('io-server-new-ticket', res.data.data, $scope.userData);
              angular.element(form).trigger('reset').parsley().reset();
              $scope.support = angular.copy(_support.support);
              $scope.tab = 0;
            }
            Notification({
              message: res.data.msj,
              replaceMessage: true
            }, res.data.event ? 'success' : 'error');

            $scope.progressbar.complete();
            $scope.save = !$scope.save;
          }, function errorCallback(data) {
            console.log("Error", data);
            Notification.error("Se ha producido un error, Por favor intente nuevamente");
            $scope.progressbar.complete();
            $scope.save = !$scope.save;
          });
      } else {
        Notification.warning('Verifique los datos requeridos!!! por favor intente de nuevo');
      }
    };

    /**
     * Crear respuesta del soporte
     * @author Desarrollador02 - Miguel Muslaco
     * @param {object} event [Datos de la respuesta de soporte]
     */
    $scope.newSupportDetalls = function (event) {
      event.preventDefault();
      var form = event.target;
      if (angular.element(form).parsley().validate()) {
        if(self.tickersInfo.estado != "NUEVO"){
          $scope.save = !$scope.save;
          $scope.progressbar.start();
          $scope.supportDetalls.sticker = self.tickersInfo._id;
          $scope.supportDetalls.attachments = angular.copy($scope.support.attachments);
          _support.newSupportDetalls($scope.supportDetalls)
            .then(function successCallback(data) {
              if (data.data.event) {
                $scope.support.attachments = [];
                data.data.data.assigned_users = [];
                data.data.data.assigned_users.push($scope.$parent.userData);
                var timer = self.dateDifference(data.data.data.fecha_registro);
                data.data.data.time = timer.full;
                data.data.data.infoDate = timer.infoDate;
                angular.element(form).trigger('reset').parsley().reset();
                socket.emit('io-server-new-response', data.data.data, self.tickersInfo, $scope.userData);
                socket.emit('io-server-update-sticker', self.tickersInfo._id);
              }
              $scope.progressbar.complete();
              $scope.save = !$scope.save;
              Notification({
                message: data.data.msj,
                replaceMessage: true
              }, data.data.event ? 'success' : 'error');
            }, function errorCallback(data) {
              console.log("Error", data);
              $scope.progressbar.complete();
              $scope.save = !$scope.save;
            });
        }else{
          Notification.warning('Debe cambiar el estado!!! por favor intente de nuevo');
        }
      } else {
        Notification.warning('Verifique los datos requeridos!!! por favor intente de nuevo');
      }
    };

    /**
     * Crear un nuevo contacto de la empresa
     * @author Desarrollador02 - Miguel Muslaco
     * @param {object} event [Datos de la empresa]
     */
    $scope.newConct = function (event) {
      event.preventDefault();
      var form = event.target;
      if (angular.element(form).parsley().validate()) {
        if ($scope.support.company !== '') {
          $scope.conct.company = $scope.support.company;
          _support.newConct($scope.conct)
            .then(function successCallback(data) {
              if (data.data.event && data.data.data._id !== undefined) {
                angular.element(form).trigger('reset').parsley().reset();
                angular.element('#modalContact').modal('hide');
                self.contactComp.push(data.data.data);
                $scope.actiselec = true;
              }
              Notification({
                message: data.data.msj,
                replaceMessage: true
              }, data.data.event ? 'success' : 'error');

            }, function errorCallback(data) {
              console.log("Error", data);
            });
        } else {
          Notification.warning('Selecione la empresa que deseé !!! por favor intente de nuevo');
        }
      } else {
        Notification.warning('Verifique los datos requeridos!!! por favor intente de nuevo');
      }
    };


    /**
     * [description]
     * @method changeStatusTickect
     * @param  {String} status [Estado del ticket]
     * @return {$http}
     */
    $scope.changeStatusTickect = function (status) {
      if ((status == "CERRADO" || status == "CONFIRMADO" || status == "EN ESPERA") && $scope.supportDetalls.response == '') {
        SweetAlert.swal({
          type: "warning",
          title: "Advertencia",
          text: "Para poder realizar esta acción debe dejar un comentario, Por favor intente nuevamente!!!",
          showCancelButton: false,
          confirmButtonColor: "#ec9150",
          confirmButtonText: "Ok",
          closeOnConfirm: true,
        });
        return false;
      } else {
        SweetAlert.swal({
          title: "Cambiar a : " + status,
          text: "Confirma que desea cambiar el estado del ticket de soporte?",
          showCancelButton: true,
          confirmButtonColor: "#ec9150",
          confirmButtonText: "Confirmar",
          showLoaderOnConfirm: true,
          preConfirm: function (confirm) {
            if (confirm) {
              $scope.save = !$scope.save;
              $scope.progressbar.start();
              return _support.changeStatusTicket(self.tickersInfo._id, status)
                .then(function successCallback(res) {
                  if (res.data.event) {
                    self.SendMessageStatus();
                    socket.emit('io-server-update-sticker', self.tickersInfo._id);
                  }
                  $scope.progressbar.complete();
                  $scope.save = !$scope.save;
                  Notification({
                    message: res.data.msj,
                    replaceMessage: true
                  }, res.data.event ? 'success' : 'error');
                }, function errorCallback(error) {
                  console.log("Error", error);
                  $scope.progressbar.complete();
                  $scope.save = !$scope.save;
                });
            }
          },
          allowOutsideClick: false
        });

      }
    };

    /**
     * Cambiar estado de la prioridad
     * @author Desarrollador02 - Miguel Muslaco
     * @returns {boolean}
     */
    $scope.changePriority = function () {
      if ($scope.supportDetalls.priority == undefined) {
        Notification({
          message: "Por favor seleccione el tipo de prioridad a cambiar",
          replaceMessage: true
        }, 'warning');
        return false;
      } else {
        SweetAlert.swal({
          title: 'CAMBIAR PRIORIDAD',
          html: '<p class="txtcomt">Para cambiar la prioridad del <b>ticket</b> es obligatorio dejar un comentario</p>',
          input: 'textarea',
          showCancelButton: true,
          confirmButtonText: 'Actualizar',
          showLoaderOnConfirm: true,
          preConfirm: function (resput) {
            return _support.changePriority(self.tickersInfo._id, $scope.supportDetalls.priority, resput)
              .then(function successCallback(res) {
                if (res.data.event) {
                  $scope.supportDetalls.response = "<b>Prioridad a cambiado: </b><a>" +
                    ($scope.supportDetalls.priority) + "</a> a <a>" + (self.tickersInfo.prioridad) + "</a><br>" +
                    "<b>Fecha:</b> " + $filter('date')(new Date(), 'yyyy-MM-dd h:mma') + "<br><br>" + resput;
                  self.SendMessageStatus();
                }
                Notification({
                  message: res.data.msj,
                  replaceMessage: true
                }, res.data.action);
              }, function errorCallback(error) {
                console.log("Error", error);
              });
          },
          allowOutsideClick: false
        });
      }
    };

    /**
     * Reasignar usuario del ticket
     * @author Desarrollador02 - Miguel Muslaco
     * @returns {boolean} [Datos del tickert del usuario]
     */
    $scope.reignUser = function () {
      if (self.tickersInfo.estado !== "CONFIRMADO" && self.tickersInfo.estado !== "CERRADO") {
        if ($scope.supportDetalls.Reacticket == undefined || $scope.supportDetalls.Reacticket == 'undefined' || $scope.supportDetalls.Reacticket == '') {
          Notification({
            message: "Por favor seleccione el agente a reasignar",
            replaceMessage: true
          }, 'warning');
          return false;
        } else {

          SweetAlert.swal({
            title: 'REASIGNAR SOPORTE',
            html: '<p class="txtcomt">Para reasignar el usuario del <b>ticket</b> es obligatorio dejar un comentario</p>',
            input: 'textarea',
            showCancelButton: true,
            confirmButtonText: 'Actualizar',
            showLoaderOnConfirm: true,
            preConfirm: function (resput) {
              return _support.changeUserTicket(self.tickersInfo._id, $scope.supportDetalls.Reacticket, resput)
                .then(function successCallback(res) {
                  var user = $filter('filter')(self.allUsuarios, {
                    "_id": $scope.supportDetalls.Reacticket
                  }, true)[0];
                  if (res.data.event) {
                    $scope.supportDetalls.response = "<b>Reasignado a: </b><a>" + (user.name + " " + user.lastname) + "</a><br>" +
                      "<b>Fecha:</b> " + $filter('date')(new Date(), 'yyyy-MM-dd h:mma') + "<br><br>" + resput;
                    self.SendMessageStatus();
                  }

                  Notification({
                    message: res.data.msj,
                    replaceMessage: true
                  }, res.data.event ? 'success' : 'error');

                }, function errorCallback(error) {
                  console.log("Error", error);
                });
            },
            allowOutsideClick: false
          });

        }
      } else {
        Notification({
          message: "No se puede reasignar el caso una vez CERRADO y CONFIRMADO el caso",
          replaceMessage: true
        }, 'warning');
      }
    };

    /**
     * Enviar respuesta del soporte desde cambiar estado
     * @author Desarrollador02 - Miguel Muslaco
     */
    this.SendMessageStatus = function () {
      $scope.supportDetalls.sticker = self.tickersInfo._id;
      $scope.supportDetalls.attachments = angular.copy($scope.support.attachments);
      _support.newSupportDetalls($scope.supportDetalls)
        .then(function successCallback(data) {
          if (data.data.event) {
            $scope.support.attachments = [];
            data.data.data.assigned_users = [];
            data.data.data.assigned_users.push($scope.$parent.userData);
            var timer = self.dateDifference(data.data.data.fecha_registro);
            data.data.data.time = timer.full;
            data.data.data.infoDate = timer.infoDate;
            angular.element("#newSupportDetalls").trigger('reset').parsley().reset();
            socket.emit('io-server-new-response', data.data.data, self.tickersInfo, $scope.userData);
            socket.emit('io-server-update-sticker', self.tickersInfo._id);
          }
        }, function errorCallback(data) {
          console.log("Error", data);
        });
    };

    /**
     * Actualizar la informacion de un soporte
     * @author Desarrollador02 - Miguel Muslaco
     * @param {object} eve
     */
    $scope.updateSupport = function (eve) {
      eve.preventDefault();
      var form = eve.target;
      if (angular.element(form).parsley().validate()) {
        $scope.progressbar.start();
        $scope.save = !$scope.save;
        $scope.support._id = self.tickersInfo._id;
        _support.updateSupport($scope.support)
          .then(function successCallback(res) {
            $scope.save = !$scope.save;
            Notification({
              message: res.data.msj,
              replaceMessage: true
            }, res.data.event ? 'success' : 'error');
            $scope.progressbar.complete();

          }, function errorCallback(data) {
            $scope.progressbar.complete();
            $scope.save = !$scope.save;
            Notification.error("Se ha producido un error, Por favor intente nuevamente");
          });
      } else {
        Notification.warning('Ingrese los dato del formulario y reintente');
      }
    };

    /**
     * Se vigila el select de la empresa
     * @author Desarrollador02 - Miguel Muslaco
     * @param {object} event [Datos del contacto]
     **/
    $scope.$watch('support.company', function (newValue, oldValue) {
      if (newValue !== undefined && newValue !== '' && newValue !== null) {
        $scope.actiselecBTN = true;
        return _support.getContactComp(newValue).then(function (data) {
          self.contactComp = [];
          if (data.data.event) {
            self.contactComp = data.data.data;
            $scope.actiselec = true;
            Notification({
              message: data.data.msj,
              replaceMessage: true
            }, data.data.event ? 'success' : 'error');
          } else {
            $scope.actiselec = false;
          }
        }).catch(function (erro) {
          Notification.warning('¡Error! Por favor intente nuevamente!');
        });
      } else {
        $scope.actiselecBTN = false;
      }

    });

    /**
     * Se vigila el select de la contacto de la empresa
     * @author Desarrollador02 - Miguel Muslaco
     * @param {object} event [Datos del contacto]
     **/
    $scope.$watch('support.mainContact', function (newValue, oldValue) {
      var user = false;
      if (newValue.length) {
        angular.forEach(self.contactComp, function (value, key) {
          (newValue === value._id) && (user = value);
        });
        $scope.support.emailContact = user.correo;
        $scope.support.telContact = user.telefono;
      }
    });

    /**
     * se vigila el filtro de los stickers
     **/
    $scope.$watch(function () {
      return self.allSoports;
    }, function (value) {
      self.allSoports = value;
      if (value !== undefined && value.length > 0)
        $scope.reload = true;
    });

    /**
     * Funcion de filtro de datos
     * @author Desarrollador02 - Miguel Muslaco
     * @param   {object} str [[Description]]
     * @returns {object}
     */
    this.regex = function (str) {
      if (str == undefined)
        str = '';
      var reg = new RegExp(".*" + $filter('slugify')(str) + ".*", "ig");
      return reg;
    };

    /**
     * Funcion de filtro de datos en  tabla
     * @author Desarrollador02 - Miguel Muslaco
     * @param   {object}   item [[Description]]
     * @returns {object}
     */
    $scope.fnSearch = function (item) {
      var number = true;
      if ($scope.search.number !== '' && $scope.search.number !== undefined)
        number = $scope.search.number == item.number;
      if (
        self.regex($scope.search.company).test($filter('slugify')(item.company[0].nomb_comercial)) &&
        self.regex($scope.search.status).test($filter('slugify')(item.estado)) &&
        self.regex($scope.search.priority).test($filter('slugify')(item.prioridad)) &&
        self.regex($scope.search.type).test($filter('slugify')(item.tipo)) &&
        self.regex($scope.search.dateRequest).test($filter('date')(item.fecha_solicitud, 'yyyy-MM-dd')) &&
        self.regex($scope.search.category).test($filter('slugify')(item.categoria)) &&
        self.regex($scope.search.assigned).test($filter('slugify')(item.assignedUser[0].name + item.assignedUser[0].lastname)) &&
        number
      ) return item;
    };

    /**
     * Información del usuario
     * @author Desarrollador02 - Miguel Muslaco
     * @param   {object} u [Datos del usuario]
     * @returns {object}
     */
    self.getInfoUser = function (u) {
      angular.forEach(self.allUsuarios, function (value, key) {
        if (u === value._id) {
          console.log(u, u === value._id, value);
          return value;
        }
      });
    };

    /**
     * Compartir ticket
     * @method shareTicket
     * @param  {Object} user [usuario a compartir]
     * @return {[type]}      [description]
     */
    $scope.shareTicket = function (user) {
      if (self.tickersInfo.share.indexOf(user._id) === -1) {
        self.tickersInfo.share.push(user._id);
        _support.updateShareTicket(self.tickersInfo)
          .then(function successCallback(res) {
            console.log("successCallback", res);
          }, function errorCallback(error) {
            console.log("errorCallback", error);
          });
      }
    };

    /**
     * Remover usaurio de compartidos de un ticket
     * @method removeShareTicket
     * @param  {string} u [usuario]
     * @return {[type]}   [description]
     */
    $scope.removeShareTicket = function (u) {
      var index = self.tickersInfo.share.indexOf(u);
      if (index !== -1) {
        self.tickersInfo.share.splice(index, 1);
        _support.updateShareTicket(self.tickersInfo)
          .then(function successCallback(res) {
            console.log("successCallback", res);
          }, function errorCallback(error) {
            console.log("errorCallback", error);
          });
      }
    };

    /**
     * Marcar como vistas las notificaciones
     * @method markViewed
     * @return {[type]} [description]
     */
    $scope.markViewed = function () {
      if ($location.search().viewed !== undefined) {
        _support.markViewed($location.search().viewed)
          .then(function successCallback(res) {
            console.log(res);
            if (res.data.event) {
              $scope.userData.cantInbox = $scope.userData.cantInbox - 1;
            }
          }, function errorCallback(error) {
            console.log(error);
            Notification.warning('¡Error! al marcar la entrada como vista, por favor reintente!');
          });
      }
    };

    /**
     * Funcion donde espero respuesta
     * del servidor para actualizar soportes
     **/
    socket.on("io-add-new-ticket", function (data) {
      if (typeof data === "object") {
        $scope.$apply(function () {
          data.time = '';
          self.allSoports.unshift(data);
        });
      }
    });

    /**
     * Funcion donde espero respuesta del servidor
     * para actualizar los soportes
     **/
    socket.on("io-add-update-sticker", function (idem) {
      self.getSoports();
      if ($location.path() !== '/soporte') {
        self.infoTickets();
      }
    });

    /**
     * Funcion donde responder mensajes del servidor
     * para actualizar mensajes
     **/
    socket.on("io-add-new-response", function (data) {
      if ($location.path() !== '/soporte') {
        if (typeof data === "object" && typeof self.tickersInfo === "object") {
          if (data.sticker === self.tickersInfo._id) {
            $scope.$apply(function () {
              self.tickersInfo.respuestas.push(data);
              $timeout(function () {
                $('body,html').stop(true, true).animate({
                  scrollTop: document.body.scrollHeight
                }, 1000);
              }, 1000);
            });
          }
        }
      }
    });
}]);
