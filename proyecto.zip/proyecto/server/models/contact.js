var async = require('async');
var conect = require('../config/mongoose.js');
var Mycrypt = require('../config/crypto.js');
var Messages = require('../lib/Messages.js');
var Helpers = require('../helpers/helpers.js');
var Promise = require('promise');
var fs = require('fs');

var getAllContact = function () {
  return new Promise(function (resolve, reject) {
    global.db.contact.aggregate([
      {
        $lookup: {
          from: "clientes",
          localField: "id_cliente",
          foreignField: "_id",
          as: "company"
        }
      }
    ], function (error, data) {
      if (error) {
        reject({
          event: false,
          data: error
        });
      } else {
        if (data !== null)
          resolve({
            event: true,
            data: data
          });
      }
    });
  });
};

var newConct = function (data) {
  var insert = new global.db.contact({
    id_cliente: data.company,
    nombre: data.fullname,
    telefono: data.phones,
    correo: data.email
  });
  return new Promise(function (resolve, reject) {
    insert.save(function (error, data) {
      if (error) {
        resolve({
          event: false,
          msj: error.message
        });
      } else {
        global.db.contact.aggregate([
          {
            $match: {
              _id: global.db.mongoose.Types.ObjectId(data._id)
            }
            },
          {
            $lookup: {
              from: "clientes",
              localField: "id_cliente",
              foreignField: "_id",
              as: "company"
            }
      }
          ], function (error, data) {
          data = data[0];
          if (error) {
            resolve({
              event: false,
              data: error,
              msj: error.message
            });
          } else {
            resolve({
              event: data._id !== undefined,
              data: data,
              msj: data._id !== undefined ? Messages.zonesafe.tickets.success.newConct : Messages.zonesafe.tickets.error.newConct
            });
          }
        });
      }
    });
  });
};
/**
 * Actualizar los contacto
 * @author Desarrollador02 - Miguel Muslaco
 * @param   {object}   Contact [Datos del contacto]
 * @returns {object} 
 */
var update = function (Contact) { 
  return new Promise(function (resolve, reject) {
    global.db.contact.update({
      _id: Contact._id
    }, {
    id_cliente: Contact.company,
    nombre: Contact.fullname,
    telefono: Contact.phones,
    correo: Contact.email
    }, function (error, data) {
      if (error) {
        reject({
          event: false,
          data: error,
          msj: error.message
        });
      } else {
        resolve({
          event: data.nModified === 1,
          data: data,
          msj: data.nModified === 1 ? Messages.zonesafe.contact.success.update : Messages.zonesafe.contact.error.update
        });
      }
    });
  });
};

var disableContact = function (contact) {
  return new Promise(function (resolve, reject) {
    global.db.contact.update({
      _id: contact._id
    }, {
      estado: contact.estado,
    }, function (error, data) {
      if (error) {
        reject({
          event: false,
          data: error,
          msj: error.message
        });
      } else {
        resolve({
          event: data.nModified === 1,
          data: data,
          msj: data.nModified === 1 ? Messages.zonesafe.contact.success.disableContact : Messages.zonesafe.contact.error.disableContact
        });
      }
    });
  });
};
/**
 * [Listado de funciones disponibles]
 * @type {Object}
 */
var contact = {
  "getAllContact": getAllContact,
  "newConct": newConct,
  "disableContact": disableContact,
  "update": update,
};

module.exports = contact;