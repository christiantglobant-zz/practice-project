/***************************************************
 * Users
 * @package Angular
 * @author Naycool Gonzalez <naycoolgonzalez@gmail.com>
 * @description: model de usuarios
 ****************************************************/

var async = require('async');
var conect = require('../config/mongoose.js');
var Mycrypt = require('../config/crypto.js');
var Messages = require('../lib/Messages.js');
var Helpers = require('../helpers/helpers.js');
var Promise = require('promise');
var fs = require('fs');

var raiz = "app/uploads";
var folder = "users";

/**
 * Verificar credenciales de un usuario
 * @method verifyCredentials
 * @param  {String} username [username]
 * @param  {String} password [password]
 * @return {Promise}
 */
var verifyCredentials = function (username, password) {
  password = Mycrypt.encrypt(password);

  return new Promise(function (resolve, reject) {
    global.db.users.findOne({
      user:username,
      password:password,
    }, function (error, data) {
      if (error) {
        reject({
          event: false,
          data: error,
          msj: Messages.global.error.error
        });
      } else {

        if (data !== null)
          global.db.users.update({
            user: username
          }, {
            lastlogin: new Date()
          }, function (error, data) {
            console.log("update login", error, data);
          });

        resolve({
          event: data !== null,
          data: data,
          msj: data !== null ? Messages.global.success.login : Messages.global.error.login
        });
      }
    });
  });
};


/**
 * Crear Nuevo Usuario
 * @param  {Object} user [Datos del usuario]
 * @return {promise}
 */
var newUser = function (user, create) {

  var path = raiz + "/" + folder;

  if (!fs.existsSync(raiz))
    fs.mkdirSync(raiz);
  if (!fs.existsSync(path))
    fs.mkdirSync(path);

  var insert = new global.db.users({
    user: user.email,
    email: user.email,
    name: user.name,
    lastname: user.lastname,
    tel: user.tel,
    password: Mycrypt.encrypt(user.password),
    lastlogin: '',
    created_by: create,
    status: true
  });
  return new Promise(function (resolve, reject) {
    insert.save(function (error, data) {
      if (error) {
        resolve({
          event: false,
          data: error,
          msj: error.errmsg
        });
      } else {
        if (Helpers.emptyDatas([user.image, data._id])) {
          data.image = data._id + '.jpg';
          user.image = user.image.replace("data:image/jpeg;base64,", "");
          fs.writeFile(path + "/" + data._id + ".jpg", user.image, {
            encoding: 'base64'
          }, function (err) {
            console.log(err);
            global.db.users.update({
                _id: data._id
              }, {
                image: data._id + '.jpg'
              }, function (error, update) {

              });
          });
        }
        resolve({
          event: true,
          data: data,
          msj: Messages.zonesafe.users.success.new
        });
      }
    });
  });
};

/**
 * Actualziar perfil de un usuario
 * @method update
 * @param  {object} user [Datos del usuario]
 * @return {Promise}
 */
var update = function (user) {
  var path = raiz + "/" + folder;
  if (user.image.split('.').pop() !== "jpg") {
    var img = user.image.replace("data:image/jpeg;base64,", "");
    user.image = user._id + ".jpg";
    fs.writeFile(path + "/" + user._id + ".jpg", img, {
      encoding: 'base64'
    }, function (err) {
      console.log(err);
    });
  }

  return new Promise(function (resolve, reject) {
    global.db.users.update({
      _id: user._id
    }, {
      name: user.name,
      lastname: user.lastname,
      tel: user.tel,
      image: user.image,
      lastUpdate: new Date()
    }, function (error, data) {
      if (error) {
        reject({
          event: false,
          data: error,
          msj: error.message
        });
      } else {
        data.img = user.image;
        resolve({
          event: data.nModified === 1,
          data: data,
          msj: data.nModified === 1 ? Messages.zonesafe.users.success.update : Messages.zonesafe.users.error.update
        });
      }
    });
  });
};

/**
 * Cambiar contraseña
 * @method changePassword
 * @param  {String} password
 * @param  {String} user [usuario]
 * @return {Promise}
 */
var changePassword = function (password, user) {

  return new Promise(function (resolve, reject) {
    global.db.users.update({
      _id: user
    }, {
      password: Mycrypt.encrypt(password)
    }, function (error, data) {
      if (error) {
        reject({
          event: false,
          data: error,
          msj: error.message
        });
      } else {
        data.img = user.image;
        resolve({
          event: data.nModified === 1,
          data: data,
          msj: data.nModified === 1 ? Messages.zonesafe.users.success.changePassword : Messages.zonesafe.users.error.changePassword
        });
      }
    });
  });
};



/**
 * Listar todos los usuarios disponibles
 * @author Desarrollador02 - Miguel Muslaco
 * @returns {object}
 */
var allusers = function () {
  return new Promise(function (resolve, reject) {
    global.db.users.find({}, function (error, data) {
      if (error) {
        reject({
          event: false,
          data: error,
          msj: Messages.global.error.error
        });
      } else {
        resolve({
          event: data.length > 0,
          data: data,
          msj: data.length ? Messages.zonesafe.users.success.allUsers : Messages.zonesafe.users.error.allUsers
        });
      }
    });
  });
};

users = {
  "changePassword": changePassword,
  "verifyCredentials": verifyCredentials,
  "newUser": newUser,
  "allusers": allusers,
  "update": update,
};

module.exports = users;
