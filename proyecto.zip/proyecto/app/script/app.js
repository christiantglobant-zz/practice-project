/***************************************************
 * App
 * @package Angular
 * @subpackage Js
 * @author Naycool Gonzalez <naycoolgonzalez@gmail.com>
 *         Developer web
 *
 * Description: Instancia de la app
 ****************************************************/
var socket = io.connect('urlSocket',{'forceNew': true});

if(Push.Permission.get() !== "granted")
    Push.create("Mensajes permitidos", {
      body: "Asi se mostraran las notificaciones",
      icon: 'app/imagen/Vulcano-txt.png',
      timeout: 12000,
      tag: 'Permission',
      onClick: function () {
        window.focus();
        this.close();
      }
    });

var app = angular.module('app', [
  // Angular modules
  'ngRoute',
  'ngAnimate',
  'ngAria',
  'ngSanitize',
  'ngStorage',
  'ngProgress',
  'ngResource',
  'oitozero.ngSweetAlert',
  //Modulos
  'ui-notification',
  'ui.bootstrap',
  'ui.select2',
  'angular-medium-editor',
  'cgBusy',
  'googlechart'
]).config(['NotificationProvider', function (NotificationProvider) {
  NotificationProvider.setOptions({
    delay: 3000,
    startTop:60,
    startRight: 10,
    verticalSpacing: 20,
    horizontalSpacing: 20,
    positionX: 'right',
    positionY: 'top'
  });
}]);


/**
 * [Remplazar caracteres especiales]
 * @method slugify
 * @return [String]
 */
app.filter('slugify', function () {
  return function (input) {
    var tittles = "ÃÀÁÄÂÈÉËÊÌÍÏÎÒÓÖÔÙÚÜÛãàáäâèéëêìíïîòóöôùúüûÑñÇç";
    var original = "AAAAAEEEEIIIIOOOOUUUUaaaaaeeeeiiiioooouuuunncc";
    for (var i = 0; i < tittles.length; i++) {
      input = input.replace(tittles.charAt(i), original.charAt(i))
        .toLowerCase();
    }
    return input;
  };
});
