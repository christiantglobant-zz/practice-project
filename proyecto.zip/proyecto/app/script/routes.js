/***************************************************
 * Routes
 * @package Angular
 * @subpackage Js
 * @author Miguel Muslaco <mjmuslaco@gmail.com>
 *         Developer web
 *
 * Description: Rutas de la App
 ****************************************************/
(function () {
  'use strict';
  angular.module('app')
    .config([
    '$routeProvider', '$locationProvider',
      function ($routeProvider, $locationProvider) {
        $routeProvider
          .when('/', {
            title: "Login",
            templateUrl: 'app/views/login.html',
            controller: "login",
            controllerAs: "self"
          })
          .when('/login', {
            title: 'Login',
            templateUrl: 'app/views/login.html',
          })
          .when('/config/users', {
            title: 'Configuración > Usuarios',
            templateUrl: 'app/views/users.html',
            controller: 'usersCtrl',
            controllerAs: 'self'
          })
          .when('/cpanel', {
            title: 'Panel de control',
            templateUrl: 'app/views/cpanel.html',
            controller: "cpanelCtrl",
            controllerAs: "self"
          })
          .when('/soporte/ticket/:nticket', {
            title: 'Seguimiento de ticket',
            templateUrl: 'app/views/responder.html',
            controller: "supportCtrl",
            controllerAs: "self"
          })
          .when('/soporte', {
            title: 'Soporte',
            templateUrl: 'app/views/support.html',
            controller: "supportCtrl",
            controllerAs: "self"
          })
          .when('/soporte#:idem', {
            title: 'Soporte',
            templateUrl: 'app/views/support.html',
            controller: "supportCtrl",
            controllerAs: "self"
          })
          .when('/history', {
            title: 'Historial',
            templateUrl: 'app/views/history.html',
            controller: "cpanelCtrl",
            controllerAs: "self"
          })
          .when('/reports', {
            title: 'Historial',
            templateUrl: 'app/views/report.html',
            controller: "reportsCtrl",
            controllerAs: "self"
          })
          .when('/clientes', {
            title: 'Soporte',
            templateUrl: 'app/views/clientes.html',
            controller: "clientCtrl",
            controllerAs: "self"
          })
          .when('/contacts', {
            title: 'Contactos',
            templateUrl: 'app/views/contact.html',
            controller: "contactCtrl",
            controllerAs: "self"
          })
          .when('/profile', {
            title: 'Perfil',
            templateUrl: 'app/views/profile.html',
            controller: "profileCtrl",
            controllerAs: "self"
          })
          .when('/editar/cliente/:idem', {
            title: 'Perfil',
            templateUrl: 'app/views/editar_cliente.html',
            controller: "clientCtrl",
            controllerAs: "self"
          })
          .when('/editar/soporte/:idem', {
            title: 'Perfil',
            templateUrl: 'app/views/edit-support.html',
            controller: "supportCtrl",
            controllerAs: "self"
          })
          .when('/reports/tickets', {
            title: 'Reportes > Todos los soportes',
            templateUrl: 'app/views/reports-all-tickets.html',
            controller: "reportsCtrl",
            controllerAs: "self"
          })
          .when('/inbox', {
            title: 'Inbox',
            templateUrl: 'app/views/inbox.html',
            controller: "inboxCtrl",
            controllerAs: "self"
          })
          .when('/404', {
            templateUrl: 'app/views/errors/404.html'
          }).otherwise({
            redirectTo: '/404'
          });

        $locationProvider.html5Mode(true);
      }]).run(['$rootScope', function ($rootScope) {
      $rootScope.$on('$routeChangeSuccess', function (event, current, previous) {
        $rootScope.title = current.$$route.title;
      });
  }]);
})();
