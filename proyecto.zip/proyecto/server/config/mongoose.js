if (!global.hasOwnProperty('db')) {

  var mongoose = require('mongoose');

  var dbName = 'support';

  mongoose.connect('127.0.0.1:27017/' + dbName, function (error) {
    if (error) {
      throw error;
    } else {
      console.log('Conectado a MongoDB');
    }
  });

  global.db = {
    mongoose: mongoose,
    //models
    users: require('../models/schemas/users')(mongoose),
    supports: require('../models/schemas/supports')(mongoose),
    clientes: require('../models/schemas/clientes')(mongoose),
    supportsDetail: require('../models/schemas/supportsDetail')(mongoose),
    contact: require('../models/schemas/contact')(mongoose),
    log_supports: require('../models/schemas/log_supports')(mongoose),
  };

}

module.exports = global.db;
