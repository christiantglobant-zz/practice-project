/***************************************************
 * Manage Soporte controles
 * @package Angular
 * @subpackage - app - Script
 * @author Miguel Muslaco <mjmuslaco@gmail.com>
 *         Developer web
 ****************************************************/

app.controller('clientCtrl', [
'$scope',
'$location',
'$filter',
'Notification',
'ngProgressFactory',
'_cropper',
'_client',
function (
    $scope,
    $location,
    $filter,
    Notification,
    ngProgressFactory,
    _cropper,
    _client) {

    /** instancia de este controlador **/
    var self = this;

    //Barra de progreso
    $scope.progressbar = ngProgressFactory.createInstance();

    /** Variable que funciona como switch **/
    $scope.reload = false;

    /** Objeto a buscar **/
    $scope.search = {};

    /** Se copie el objeto de clientes  **/
    $scope.client = angular.copy(_client.client);

    /** variable global para croppers **/
    $scope.cropper = _cropper;

    /** Configuración de mensaje de precarga **/
    $scope.configMsj = {
      delay: 0,
      minDuration: 0,
      message: 'Cargando datos...',
      backdrop: true,
      promise: null
    };

    /** filtar datos  **/
    $scope.filter = function (filter, value) {
      $scope.search[filter] = value;
    };

    /** Configuracion del recorte **/
    this.configPhoto = angular.copy(_client.configPhoto);

    /** Listar todos  los clientes **/
    this.allClient = [];

    /** Listar la informacion del cliente editar **/
    this.clientInfo = [];

    /** Cantidad de registro de clientes**/
    $scope.showCant = "10";

    /**
     * Activar la pestaña de buscar cliente
     * @author Desarrollador02 - Miguel Muslaco
     */
    this.searchClient = function () {
      $scope.tab = 0;
    };

    /** Tomar el ID a buscar **/
    var cliente_id = $location.path().split("/")[3];

    /**
     * Listar la informacion del clientes
     * @author Desarrollador02 - Miguel Muslaco
     */
    this.getInfoClient = function () {
      _client.getInfoClient(cliente_id)
        .then(function successCallback(res) {
          self.clientInfo = res.data.data;
        }, function errorCallback(data) {
          console.log("Error", data);
          Notification.error("Se ha producido un error, Por favor intente nuevamente");
        });
    };

    /**
     * Listar todo los clientes
     * @author Desarrollador02 - Miguel Muslaco
     * @returns {object} [Datos del clientes]
     */
    this.getClients = function () {
      $scope.configMsj.promise = _client.getAllClients().then(function (data) {
        self.allClient = data.data.data.length > 0 ? data.data.data : [];
        if (!data.data.event || data.data.data.length <= 0)
          Notification.error(data.data.msj);
      }).catch(function (erro) {
        Notification.warning('¡Error! Por favor intente nuevamente!');
      });
    };

    /**
     * Funciones de recorte de la imagen
     * @private
     * @author Desarrollador02 - Miguel Muslaco
     * @param {object} instance
     */
    this._cut = function (instance) {
      $scope.client.image = $scope.cropper.cut(
        instance,
        self.configPhoto._sizes.cover.width,
        self.configPhoto._sizes.cover.height
      );
    };

    /**
     * Funcion para actualizar la imagen
     * @private
     * @author Desarrollador02 - Miguel Muslaco
     * @param {object} instance
     */
    this._cutUpdate = function (instance) {
      self.clientInfo.image = $scope.cropper.cut(
        instance,
        self.configPhoto._sizes.cover.width,
        self.configPhoto._sizes.cover.height
      );
      self.clientInfo.imageUpdate = true;
    };

    /**
     * Actualizar clientes
     * @author Desarrollador02 - Miguel Muslaco
     * @param {object} clients [Datos actualizados del cliente]
     */
    $scope.disableClient = function (clients) {
      if (typeof clients === 'object' && clients._id !== undefined && clients._id !== 'undefined') {
        clients.estado = !clients.estado;
        $scope.progressbar.start();
        _client.disableClient(clients)
          .then(function successCallback(res) {
            $scope.save = !$scope.save;
            Notification({
              message: res.data.msj,
              replaceMessage: true
            }, res.data.event ? 'success' : 'error');
            $scope.progressbar.complete();
          }, function errorCallback(data) {
            console.log("Error", data);
            $scope.progressbar.complete();
            Notification.error("Se ha producido un error, Por favor intente nuevamente");
          });
      } else {
        Notification.warning("No se enviaron todos los datos requeridos, Por favor intente nuevamente");
      }

    };

    /**
     * Neuvo cliente
     * @author Desarrollador02 - Miguel Muslaco
     * @param {object} event [Datos del cliente]
     */
    $scope.newClient = function (event) {
      event.preventDefault();
      var form = event.target;
      if (angular.element(form).parsley().validate()) {
        $scope.progressbar.start();
        $scope.save = !$scope.save;
        _client.newClient($scope.client)
          .then(function successCallback(data) {
            if (data.data.event && data.data.data._id !== undefined) {
              self.allClient.push(data.data.data);
              angular.element(form).trigger('reset').parsley().reset();
              $scope.client = angular.copy(_client.client);
              $scope.tab = 0;
            }
            Notification({
              message: data.data.msj,
              replaceMessage: true
            }, data.data.event ? 'success' : 'error');

            $scope.progressbar.complete();
            $scope.save = !$scope.save;
          }, function errorCallback(data) {
            console.log("Error", data);
            Notification.error("Se ha producido un error, Por favor intente nuevamente");
            $scope.progressbar.complete();
            $scope.save = !$scope.save;
          });
      } else {
        Notification.warning('Verifique los datos requeridos!!! por favor intente de nuevo');
      }
    };

    /**
     * Actualizar la informacion del clientes
     * @author Desarrollador02 - Miguel Muslaco
     * @param {object} eve
     */
    $scope.updateClient = function (eve) {
      eve.preventDefault();
      var form = eve.target;
      if (angular.element(form).parsley().validate()) {
        $scope.progressbar.start();
        $scope.save = !$scope.save;
        _client.updateClient(self.clientInfo)
          .then(function successCallback(res) {
            if (res.data.data.nModified) {
              $location.path('clientes');
            }
            $scope.save = !$scope.save;
            Notification({
              message: res.data.msj,
              replaceMessage: true
            }, res.data.event ? 'success' : 'error');
            $scope.progressbar.complete();
          }, function errorCallback(data) {
            $scope.progressbar.complete();
            $scope.save = !$scope.save;
            Notification.error("Se ha producido un error, Por favor intente nuevamente");
          });
      } else {
        Notification.warning('Ingrese los dato del formulario y reintente');
      }
    };

    /**
     * Filtor con contactos
     * @author Desarrollador02 - Miguel Muslaco
     * @param   {[[Type]]} str [[Description]]
     * @returns {[[Type]]} [[Description]]
     */
    this.regex = function (str) {
      if (str == undefined)
        str = '';
      var reg = new RegExp(".*" + $filter('slugify')(str) + ".*", "ig");
      return reg;
    };

    /**
     * Se vigila si hay cambio en el objeto de contacto
     **/
    $scope.$watch(function () {
      return self.allClient;
    }, function (value) {
      self.allClient = value;
      if (value !== undefined && value.length > 0)
        $scope.reload = true;
    });

    /**
     * Funcion para la busqueda de las palabras
     * @author Desarrollador02 - Miguel Muslaco
     * @param   {object}   item [Datos de la contacto]
     * @returns {object}
     */
    $scope.fnSearch = function (item) {
      var number = 3;
      if ($scope.search.status !== '' && $scope.search.status !== undefined)
        if ($scope.search.status == "true") {
          number = true;
          number = (number == item.estado);
        } else if ($scope.search.status == "false") {
        number = false;
        number = (number == item.estado);
      }

      if (self.regex($scope.search.tradename).test($filter('slugify')(item.razon_social)) &&
        self.regex($scope.search.businessName).test($filter('slugify')(item.nomb_comercial)) && number) return item;
    };

}]);