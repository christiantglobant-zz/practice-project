/**
 * Estructura de soportes
 * @author Desarrollador02 - Miguel Muslaco
 * @param   {object}   mongoose
 * @returns {object}
 */
module.exports = function (mongoose) {

  var Schema = mongoose.Schema;

  // Objeto modelo de Mongoose
  var supportSchema = new Schema({
    number: {
      type: Number,
      required: true,
      index: {
        unique: true
      }
    },
    sticker: {
      type: Number,
    },
    id_cliente: {
      type: mongoose.Schema.Types.ObjectId,
      required: true
    },
    tipo: {
      type: String,
      required: true
    },
    medio: {
      type: String,
      required: true
    },
    descripcion: {
      type: String,
      required: true
    },
    responsable: {
      type: mongoose.Schema.Types.ObjectId,
      required: true
    },
    id_contacto: {
      type: mongoose.Schema.Types.ObjectId,
      required: true
    },
    categoria: {
      type: String,
      required: true
    },
    imputabilidad: {
      type: String,
      required: true
    },
    prioridad: {
      type: String,
      required: true,
      enum: ['BAJO', 'MEDIO', 'ALTO']
    },
    asunto: {
      type: String,
      required: true
    },
    fecha_solicitud: {
      type: Date,
      default: Date.now
    },
    fecha_registro: {
      type: Date,
      default: Date.now
    },
    confirm_date: {
      type: Date,
      default: ''
    },
    attachments: {
      type: Array
    },
    share: {
      type: Array,
      default: []
    },
    estado: {
      type: String,
      enum: ['NUEVO', 'EN PROCESO', 'EN ESPERA', 'CERRADO', 'CONFIRMADO', 'CANCELADO'],
      default: 'NUEVO'
    },
    creado_por: {
      type: mongoose.Schema.Types.ObjectId,
    },
  });


  return mongoose.model('supports', supportSchema);
};
