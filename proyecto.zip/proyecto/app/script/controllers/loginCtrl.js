/***************************************************
 * Login.Signup js
 * @package JS
 * @author Miguel Muslaco <mjmuslaco@gmail.com>
 *         Developer web
 *
 * Description: Configuraciones, funciones realizar
 *               logins o registros de usuarios
 ****************************************************/

app.controller('login', [
  '$localStorage',
  '$location',
  '$scope',
  'Notification',
  '_login',
  '_support',
  function (
    $localStorage,
    $location,
    $scope,
    Notification,
    _login,
    _support) {

    var self = this; //instancia de este controlador
    $scope.$storage = $localStorage;

    $scope.login = {
      username: "",
      password: "",
    };

    /**
     * Login de usuario
     * @method logins
     * @author Desarrollador02 - Miguel Muslaco
     * @param {object} event
     */
    $scope.logins = function (event) {
      event.preventDefault();
      var form = event.target;
      if (angular.element(form).parsley().validate()) {
        _login.login($scope.login)
          .then(function successCallback(response) {
            Notification({
              message: response.data.msj,
              replaceMessage: true
            }, response.data.event ? 'success' : 'error');
            if (response.data.event && response.data.data !== null) {
              _support.loadChangesSupports()
              .then(function (res) {
                response.data.data.cantInbox = res.data.data.length;
              });
              $scope.$storage.userData = response.data.data;
              socket.emit('io-server-login', response.data.data);
              $location.path('cpanel');
            }
          }, function errorCallback(data) {
            console.log("Error", data);
            Notification.warning('Ingrese los dato del formulario y reintente');
          });
      } else {
        Notification.warning('Ingrese los dato del formulario y reintente');
      }
    };

}]);
